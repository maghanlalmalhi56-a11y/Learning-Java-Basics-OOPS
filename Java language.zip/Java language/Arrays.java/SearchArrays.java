import java.util.Scanner;

 class SearchArrays {
    public static void main(String[] args) {
        int[] numArr=ArraysUtility.inputArrays(); 
         Scanner input=new Scanner( System.in); 
         System.out.print( " Enter The number that you want to search : ");
         int x=input.nextInt();   
       SearchArr(numArr, x);
        
        
   }
   public static boolean SearchArr(int[]numArr, int key){
      for(int i=0;i<numArr.length; i++){
            if (numArr[i]==key) {
                 System.out.println("Item is found at index NO :   "+i);
                 return true;
            }
             
   }
         return false;  
     
   }

 }
