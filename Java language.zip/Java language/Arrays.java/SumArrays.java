import java.util.Scanner;

public class SumArrays {
    public static void main(String[] args) {
         System.out.println( " Welcome to Sum class in Java World \n");
         Scanner input=new Scanner( System.in); 
         System.out.print(" Enter the size of Arrays : ");
         int size = input.nextInt(); 
         int [] num = new int[size]; 
         for(int i=0 ; i<size; i++){
         System.out.print( " Enter Number of element  "+(1+i)+" :");
         num[i]=input.nextInt(); 
    }
    // int sum=0; 
    // for( int i=0; i<num.length; i++){ 
    //     sum+=num[i];
    // }
    // System.out.println( " The Sum of Arrays is : "+ sum);

    // double average = sum/num.length; 
    // System.out.println(" The Average of Arrays is : "+average);
// Easy Method by using For each loops 
    int sum = 0; 
    for (int element : num){
         sum+=element; 
    }
    System.out.println( " The sum is : "+sum);
}
}
