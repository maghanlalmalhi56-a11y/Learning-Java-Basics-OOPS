

 class SumAndAverageArrays {
    public static void main(String[] args) {
      int [] numArr=ArraysUtility.inputArrays();
      
         System.out.println(" Welcome to Sum and Average of an Arrays Class \n");
          
          long sum = Sum(numArr);
           System.out.println( " The Sum of Arrays is : "+sum); 
            double Average = Average(numArr); 
            System.out.println( " The Average of Arrays is : "+Average);
    }
     public static long Sum ( int [] numArrays){ 
      long Sum =0; 
      for( int i=0 ; i<numArrays.length; i++){ 
         Sum+=numArrays[i]; 
      }
        return Sum; 
     }
      public static double Average (int [] numArrays){ 
         double Sum = Sum(numArrays); 

        return (Sum/numArrays.length);  
}
 }