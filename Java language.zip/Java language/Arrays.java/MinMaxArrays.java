 class MinMaxArrays {
    public static void main(String[] args) {
         System.out.println( " Welcome to Maximum and minimium finding Arrays \n");

        int [] numArr=ArraysUtility.inputArrays(); 
         int max=max(numArr); 
          int min=min(numArr);
         System.out.println(" The Maximum Array is : "+max);
          
           System.out.println(" The Minimum Array is : "+min);
    }
    public static int min ( int [] numArr){
        int min = Integer.MAX_VALUE;
         for( int i=0; i<numArr.length; i++){
         if(min>numArr[i]){
            min=numArr[i];
         }
            
        
        }   
        return min; 
    }
     public static int max ( int [] numArr ){
       if( numArr.length==0){
        return Integer.MIN_VALUE; 
       }
       int max=numArr[0];
       for( int i=1; i<numArr.length;i++){ 
        max = numArr[i];
       } 
      return max; 
     }
    
}
