public class LargestArray {
    public static void main(String[] args) {
         System.out.println( " Welcome to Largest Array Class \n");
         int []NumArr=ArraysUtility.inputArrays();
          int Largest=LargestArr(NumArr) ; 
          System.out.println( " Largest Arrays is :"+Largest);
          int Smallest=SmallestArr(NumArr);
         System.out.println( " Smallest  Array is : "+Smallest);
    }
    public static int LargestArr( int []numArr){
  int largest=numArr[0]; 
  for( int i=0; i<numArr.length; i++){
    if (numArr[i]>=largest) {
      largest=numArr[i];
    }
  }
  return largest; 
}
      public static int SmallestArr( int []numArr){
  int Smallest=numArr[0]; 
  for( int i=0; i<numArr.length; i++){
    if (numArr[i]<=Smallest) {
      Smallest=numArr[i];
    }
  }
  return Smallest; 
}
}
