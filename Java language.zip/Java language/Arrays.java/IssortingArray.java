class IssortingArray {
    public static void main(String[] args) {
         System.out.println(" Welcome to Sorting check post \n ");
         int [] numArr=ArraysUtility.inputArrays(); 
        boolean Isinc=Isincreasing(numArr);
        boolean Isdec=IsDecreasing(numArr);
        if( Isdec||Isinc){ 
            System.out.println( " Array is Sorting Array ");
        }else{
             System.out.println( " Array is not Sorting Array ");
        }
    }
    public static boolean Isincreasing( int[]numArr){
        for( int i=1; i<numArr.length; i++){
            if( numArr[i]<numArr[i-1]){ 
                return false; 
            }
        }
         return true ;
    }
    public static boolean IsDecreasing( int[]numArr){
          for( int i=1; i<numArr.length; i++){
            if( numArr[i]>numArr[i-1]){ 
                return false; 
            }
        }
         return true ;
}
}