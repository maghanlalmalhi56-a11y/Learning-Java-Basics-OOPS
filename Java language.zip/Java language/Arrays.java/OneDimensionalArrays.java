public class OneDimensionalArrays {
    public static void main(String[] args) {
         System.out.println(" Welcome to Array class ");
         int [] numArr=ArraysUtility.inputArrays(); 
       //   int myArr[]=new int[5]; 
        //   myArr[0]= 98;
        //   myArr[1]= 48;
        //   myArr[2]= 94;
        //   myArr[3]= 9; 
        //   myArr[4]= 56;
           int [] myArr = { 98, 48,94 , 9, 56 }; 
        //   System.out.println( myArr[0]);
        //   System.out.println( myArr[1]);
        //   System.out.println( myArr[2]);
        //   System.out.println( myArr[3]);
        //   System.out.println( myArr[4]);
         
        for (int i=0; i<myArr.length; i++  ) {   // i<5 or length function also used 
            System.out.println( myArr[ i ]);
        }

    //  String  in Arrays 
    String [] strArr = { " ALi","Maghanlal","Bazaid" }; 
    for( int i=0; i<strArr.length; i++){ 
        System.out.println( strArr[i]);

    }





    }
}
