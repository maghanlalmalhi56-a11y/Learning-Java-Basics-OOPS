public class ReverseOfArrays {
    public static void main(String[] args) {
         
         System.out.println( " Welcome to Arrays Reversing order  \n");
         int [] numArr = ArraysUtility.inputArrays();
         System.out.println( " The Reverse Order of Arrays ");
         for( int i= numArr.length-1; i>=0; i--){  
             System.out.print( numArr[i]+"  ");
            
         }
         System.out.println( "  ");
    }
   
}
