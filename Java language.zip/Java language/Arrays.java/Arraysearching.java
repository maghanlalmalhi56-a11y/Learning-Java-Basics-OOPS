import java.util.Scanner;

 class Arraysearching {
    public static void main(String[] args) {
           Scanner input = new Scanner( System.in); 
         int [] myArr={ 2,4,5,6,7}; 
         System.out.println( " Welcome to array searching \n ");
         System.out.print( "Enter the number that you want to search : ");
         int num =input.nextInt(); 
        boolean isFound=isFound(myArr, num); 
          if ( isFound) {
            System.out.println( " Your number is  found in the arrays :"+num);
          }else{ 
            System.out.println( " Your number is not found in the arrays :"+num);
          }
    }
    public static boolean isFound( int[] arr, int num){ 
         for( int i=0; i<arr.length ; i++ ){ 
            if (arr[i]==num){ 
                return true; 
            }
         }

        return false; 
    }
}
