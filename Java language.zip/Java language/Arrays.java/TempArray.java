import java.util.Scanner;

public class TempArray {
    public static void main(String[] args) {
         System.out.println(" Welcome to Temperature Class in the Arrays \n");

       InputArr(null);
    } 
    public static int InputArr( int []arr){
         Scanner input=new Scanner( System.in); 
         System.out.print(" Enter Day Number : "+" ");
         int size=input.nextInt();
         int [] num = new int[size];
         for( int i=0; i<arr.length; i++){
         System.out.print( " Enter The Temperature of day  "+(1+i)+": ");
         num[i]=input.nextInt();
         }
        

        return size; 
    }
}
