public class TwoDimensionalArray {
    /**
     * @param args
     */
    public static void main(String[] args) {
     
        //  int [][] arr = {{2,3, 4  }, {4,5,6}, { 7,8 , 9 }}; 
        //  System.out.println(" The total length of arrays: "+ arr.length);
        //  for ( int i=0; i<arr.length; i++){ 
        //     for( int j=0; j<arr[i].length; j++){ 
        //         System.out.print( arr[i][j]+ " ");
        //     }
        //     System.out.println( );


        //  }
       int num [][]= { { 23,34,45}, {5,6,7 }, {8,9,10 }};
       int sum =0; 
       for(int i=0; i<num.length; i++){
        for(int j=0; j<num[i].length;j++){
        System.out.print( num[i][j]+ " ");
        
         sum+=num[i][j];
       }
        System.out.println( " ");
    }
      
      
    System.out.print(" Sum :"+sum); 
    // min(null);

      int []arr2= {3, 6, 7 };                 // { {4,5,6}, {7,8,9}};
      for( int x : arr2){
         for( int x2: x){ 
           System.out.println(x);
         }
     
      }



}
 
// static void min(int arr[]){    
//         int min=arr[0];    
//         for(int i=0;i<arr.length;i++){
//             for( int j=0; j<arr[i].length; j++){

//             }
//         }  
               
    
        // System.out.println(min);    


   
    

     }







      

