import java.util.Scanner;

class OccurrencesArray {
    public static void main(String[] args) {
         System.out.println( " Welcome to occurrrences Arrays class  \n");
         Scanner input=new Scanner( System.in); 
         int [] numArr=ArraysUtility.inputArrays(); 
         System.out.print( " Please Enter the number that you want to find :  ");
         int num=input.nextInt(); 
      int noOfOccurrences=noOfOccurrences(numArr, num); 
       System.out.println( " The Occurrences of Arrays " +noOfOccurrences+" Times in the Arrays");
    }
     public static int noOfOccurrences( int[] numArr, int num){
         int occu= 0; 
         for( int i=0; i<numArr.length; i++){
            if ( numArr[i]==num){
             occu++; 
            }
         }
        return occu; 
     }
}
