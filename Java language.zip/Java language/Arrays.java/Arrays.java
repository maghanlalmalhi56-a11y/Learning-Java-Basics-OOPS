import java.util.Scanner;

public class Arrays {
    public static void main(String[] args) {
        //  int marks[]=new int[3]; 
        //  marks[0]=98; 
        //  marks[1]=56; 
        //  marks[2]=45; 
          // int marks[]= { 98, 56, 45}; 
          // for ( int num : marks){ 
          //   System.out.println(num);
          // }
        //  System.out.println( marks[0]);
        //  System.out.println( marks[1]);
        //  System.out.println( marks[2]);
        //  for( int i=0; i<3 ; i++){ 
        //     System.out.println( marks[i]);
        //  }

        //   Scanner input=new Scanner( System.in);
        //   System.out.print( " Please Enter the size of Arrays: "); 
        //   int size= input.nextInt(); 
        //   System.out.print( " Please Enter number of element : ");
        //   int [] number=new int[size]; 
        //    for( int i=0; i<size; i++){
        //     number[i]=input.nextInt(); 
        //    }
        
        //   // output 
        //   for( int i=0; i<size; i++){ 
        //     System.out.println( number[i]);
        //     System.out.println( " ");
            
        //   }
    //    int [] numArr=ArraysUtility.inputArrays(); 
    //    Scanner input=new Scanner( System.in ); 
    //    System.out.print("Enter the Size of Arrays :  ");
    //    int Size =input.nextInt(); 
    //    int [] num=new int[Size]; 
    //    for ( int i= 0; i<Size; i++){ 
    //     System.out.print( "Please Enter the element of Arrays "+ (1+i)+" : ");
    //     num[i]=input.nextInt();
    //    }

    //    System.out.print( "Number that you want to Find :");
    //    int x=input.nextInt(); 
    //    for( int i=0; i<num.length; i++){
    //     if (num[i]==x) {
    //     System.out.println( " Number is found :"+i);
    //     }else { 
    //         System.out.println( " Number is not Found ");
    //     }
        
    //     }
        

    // Reverse order of Arrays 
      //  int marks[]= { 98, 56, 45}; 
      //  for( int i= marks.length-1; i>=0; i--){ 
      //    System.out.println(marks[i]);
      //  }


int marks[]= { 98, 56, 45}; 
change( marks);
System.out.println( marks[0]);

}
 static void change ( int [] arr){ 
  arr[0]= 58; 
 }
}