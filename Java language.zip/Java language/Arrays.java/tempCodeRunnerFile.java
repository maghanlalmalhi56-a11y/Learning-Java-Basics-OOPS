
        for(int j=0; j<num[i].length;j++){
        System.out.print( num[i][j]+ " ");
       }
       System.out.println( " ");