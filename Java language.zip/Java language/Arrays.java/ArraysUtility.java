import java.util.Scanner;

public class ArraysUtility {
    public static int [] inputArrays(){ 
         Scanner input =new Scanner( System.in); 
         System.out.print( " please Enter the Size of Arrays  : ");
         int size=input.nextInt(); 
         int [] num = new int[size]; 
         for( int i=0; i<size ; i++){ 
            System.out.print("please enter the element no  "+(i+1)+" : ");
             num[i]=input.nextInt(); 
         }
         return num; 
    }
}
