public class Rectangle {
    int length; 
    int width; 
     public int getArea(){ 
      return length*width; 
    }
    public int getPerimeter(){ 
      return 2*(length+width);
    }
     public static void main(String[] args) {
      System.out.println(" Welcome to Area culculating of Rectangle class \n ");
      Rectangle R1=new Rectangle(); 
      R1.length=3;
      R1.width=5;
      R1.getArea(); 
       R1.getPerimeter(); 
       System.out.println(" The Area Of Rectangle : "+R1.getArea());
       System.out.println(" The Perimeter Of Rectangle : "+R1.getPerimeter());
      
       
    }
}

