public class Employee {
 
    int salary; 
     String name; 
    //  Employee(String name, int salary){ 
    //     this.name=name;
    //     this.salary=salary;
    //  }

      public  int getSalary( int salary){ 
        return salary; 
      }
      public String getName( String name){ 
         return name;
      }
      public void setName( String n){
       name=n;
       
      }
      public static void main(String[] args) {
         Employee emp1=new Employee();
         emp1.getName(" Maghan lal");
         emp1.getSalary(34000);
          emp1.setName("Anil kumar ");
        System.out.println( emp1.getName(" Maghan lal")); 
        System.out.println( emp1.getSalary(34000));
        // System.out.println( emp1.setName("Anil kumar"));
       }
}
