 class Square {
    int side; 
    public int getArea(){ 
      return side*side; 
    }
    public int getPerimeter(){ 
      return 4*side;
    }
     public static void main(String[] args) {
      System.out.println(" Welcome to Area culculator class \n ");
      Square s1=new Square(); 
      s1.side=3;
      s1.getArea(); 
       s1.getPerimeter(); 
       System.out.println(" The Area : "+s1.getArea());
       System.out.println(" The Perimeter : "+s1.getPerimeter());
       
    }
}
