public class Mobile {
  
    void vibr( ){
        System.out.println( " Mobile is Vibratning. ");
    }
    void ring(){
        System.out.println( " Mobile is ringing. ");
    }
    void callingFriend(){ 
        System.out.println( " micheal is calling his friend.");
    }
    public static void main(String[] args) {
        Mobile mob= new Mobile(); // wihout static word have to create object class
        mob.vibr();
        mob.ring();
        mob.callingFriend();
        
      
    }
}
