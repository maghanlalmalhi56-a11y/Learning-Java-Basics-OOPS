    class Cylinder {
   private int radius; 
   private int height; 
    public void setRadius(int rad){ 
        this.radius=rad; 

    }
    public Cylinder(int radius, int height) { // constructor don't need getter and setter 
        this.radius = radius;
        this.height = height;
    }
    public int getHeight( ){ 
        return height; 
    }
     public void setHeight(int height){ 
        this.height=height;  


    }
    public int getRadius( ){ 
        return radius; 
    }
 public double surfaceArea(  ){
    return 2*Math.PI*radius*radius+2*Math.PI*radius*height;// 3.14
 }
 public double getVolume(  ){
    return Math.PI*radius*radius*height;
 }
  
    public static void main(String[] args) {
         // problem1
        Cylinder c1= new Cylinder(9,12); 
        c1.setHeight(12);
        c1.setRadius(9);
        System.out.println(c1.getHeight());
        System.out.println(c1.getRadius());  
  // problem 2
        System.out.println(c1.surfaceArea());
        System.out.println(c1.getVolume());

        Rectangle R1=new Rectangle(); 
        Rectangle R2= new Rectangle(3, 4);
        System.out.println(R1.getLength());
        System.out.println(R1.getWidth());

    }

}
 class Rectangle{
 private int length;
 private int width;
 public Rectangle() {
    this.length=4; 
    this.width=5;
 }
 public Rectangle(int length, int width) {
    this.length = length;
    this.width = width;
 }
 public int getLength() {
    return length;
 }
 public int getWidth() {
    return width;
 }
 }