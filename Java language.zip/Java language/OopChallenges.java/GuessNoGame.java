import java.util.Scanner;

public class GuessNoGame {
   
         /* create class of , which allows a user to play " Guess the number " game once.
          Game should have the following method: 
          1. constructor to generate the random number 
          2. takeUserInput() to take a user input of number 
          3. isCorrectNumber( ) to detect wether the number is entered by true. 
          4. getter and setter for noOfGuess. 
          use properties such as noOfGuess( int ), etc to get this task done !
         */
         int num; 
        GuessNoGame(int ranNum){ 
         num =ranNum; 
        
        }
        public int takeUserInput(){ 
        Scanner input=new Scanner(System.in);
        System.out.print("  Guess the number : ");
        int num= input.nextInt(); 
        return num; 
        }
         public void isCorrectNumber( ){ 
             System.out.println( "You entered correct Number ");
         }
         public static void main(String[] args) {
            GuessNoGame g1=new GuessNoGame(3); 
            g1.takeUserInput(); 
            g1.isCorrectNumber();
    }
}
