public class Tommy {
    public void hitting( ){ 
        System.out.println( " Tommy is hitting on the Rakesh kumar.");
    }
    public void running( ){ 
        System.out.println( " Tommy is running faster than Moti. ");
    }
    public void firing(){ 
        System.out.println( " Fire is the danger for the human being.");
    }
    public static void main(String[] args) {
         Tommy T1= new Tommy(); 
         T1.hitting(); 
         T1.firing(); 
         T1.running(); 

    }
}
