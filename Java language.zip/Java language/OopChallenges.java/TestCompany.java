class Company {
   private String name; 
   private int nbStore; 
    private Store []arrayStore; 
    Company(String name){ 
     this.name=name; 
     this.arrayStore=new Store[10]; 
     this.nbStore=0; 
    }
    public void addStore( Store s){ 
        
        if(nbStore < 10) {
           
            arrayStore[nbStore++] = s;
        } else {
            System.out.println("Cannot add more stores. Limit reached.");
        }
    } public int searchNbofStore(String productName) {
        int count = 0;
        for(int i=0; i<nbStore; i++) {
            if(arrayStore[i].searchProduct(productName)) {
                count++;
            }
        }
        return count;
    }

    
    public void displayAll() {
        System.out.println("Company: " + name);
        for (int i = 0; i < nbStore; i++) System.out.println("- " + arrayStore[i].getName());
    }
}


    

 class Store{       //name, location, productList, nbProduct 
   private String name; 
   private  String location; 
      private  Product[]productsList;  
      private int nbProduct; 
      Store( String name , String location){
        this.name=name; this.location=location; this.productsList=new Product[100]; this.nbProduct=0; 
      }
public  boolean searchProduct(String productName){
    
   for (int i = 0; i < nbProduct; i++) 
            if (productsList[i].getName().equalsIgnoreCase(productName)) return true;
        return false;
    }

public String getName(){ 
    return name; 
}
public void addProduct( Product p ){
if (nbProduct < 100) productsList[nbProduct++] = p;
}
public  Product deleteProduct( String productName){
   for (int i = 0; i < nbProduct; i++) {
            if (productsList[i].getName().equalsIgnoreCase(productName)) {
                Product deleted = productsList[i];
for (int j = i; j < nbProduct - 1; j++) productsList[j] = productsList[j+1];
                                productsList[--nbProduct] = null;
                return deleted;
            }
        }
        return null;
    }

public void displayAll() {
        System.out.println("Store: " + name);
        for (int i = 0; i < nbProduct; i++) System.out.println("- " + productsList[i].getName());
    }
}
 class Product {
private String name; 
private int quantity;
private double price; 
public Product ( String name , int quantity , double price) {
 this.name=name; this.quantity=quantity; this.price=price; 
}

   public String getName( ){ 
    return name; 
   } 
}


public class TestCompany {  
    public static void main(String [] args){          
        Product p1 = new Product("TV",4,34000);  
        Product p2 = new Product("Bicycle", 4, 5500);  
        Product p3 = new Product("Oven", 3,70000);  
          
        Store s1 = new Store("Makro", "Karachi");          
        Store s2 = new Store("Hypermart","Karachi");  
        s1.addProduct(p1); 
        s1.addProduct(p2); 
        s1.addProduct(p3); 
        s1.displayAll();  
        Product tempProduct = s1.deleteProduct("Bicycle"); 
        if (tempProduct!=null)  
            System.out.println("Product :"+tempProduct.getName()+ " is         deleted"); 
        else 
            System.out.println("There is no product to delete"); 
         s1.displayAll(); 
         s2.addProduct(p1); 
         s2.addProduct(p2); 
         s2.addProduct(p3); 
         s2.displayAll();  
         Company c1 = new Company("Unilever"); 
         c1.addStore(s1); 
         c1.addStore(s2); 
         c1.displayAll();  
         int n= c1.searchNbofStore("TV"); 
         System.out.println("Number of stores have TV "+n);  
          
    }  
}  
