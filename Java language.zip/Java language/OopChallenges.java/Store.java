
public class Store {

}
