 class Person {
    private String firstName, lastName; 
   public Person ( String firstname, String lastName){ 
     this.firstName=firstname; 
     this.lastName=lastName; 
   }
   public  void displayDetail(){ 
    System.out.println( " Full name : "+firstName + " "+lastName);
   }
}
  class Students extends Person {

    private int id; 
    private String course, teacherName; 
    Students(int id, String firstname,String  lastname,String course, String teacherName){
    super(firstname, lastname); this.teacherName=teacherName; this.course=course; this.id=id;  
    }
    public void displayDetail(){
      super.displayDetail();
      System.out.println(" ID :"+id + "  "+" Teacher Name : "+ teacherName +" Course :"+course);
    }
}

 class Teacher extends Person {
private double  salary; 
private String subject; 
Teacher(String firstName , String lastName, double salary , String subject){
   super(firstName,lastName);this.salary= salary; this.subject=subject; 
}

   public void displayDetail(){
      super.displayDetail();
      System.out.println(" Salary :"+salary+  " Subject: "+subject);
    }
}

 class TestPerson {
  public static void main(String[] args) {
     Person p1= new Person(" Maghan lal ", " Malhi"); 
     Students st1=new Students(73, "Maghan ", "Lal Malhi ", "Oop", "Sir Saleem ");
     Students st2=new Students(71, " Shanker ", " Kumar ","Oop", "Sir Saleem ");
     Teacher t1=new Teacher(" Muhammed", " Saleem ", 350000,  " Object-Oriented-Programming");
     Teacher t2=new Teacher(" Bulbul", " Jaan ", 350000,  " Calculus-Analytical-Geometery ");
    System.out.println("********* Persons Details *********\n");
     p1.displayDetail();
     System.out.println("\n********* Students Details *********\n");
     st1.displayDetail(); 
     st2.displayDetail();
     System.out.println("\n********* Teachers Details *********\n");
     t1.displayDetail();
     t2.displayDetail();
  }
}