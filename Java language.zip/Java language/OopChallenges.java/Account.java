import java.util.Date;

class Account {
   private int id; 
   private double balance; 
   private double InterestRate; 
   private Date dateCreated; 
   Account( int id, double balance , double interestRate){ 
  this.id=id; 
  this.balance=balance; 
  this.InterestRate=interestRate; 
  this.dateCreated=new Date(); 
   }
 public boolean withdraw(double amount  ){ 
    if (amount<=balance) {
        balance=balance-amount;
        return true;
    }else { 
       System.out.println( " Insuficient balc=ance : ");
    }
     return false; 
   
 }
 public void deposit( double totalamount ){ 
    balance= balance+totalamount; 
 }
 public int getId() {
    return id;
 }
 public void setId(int id) {
    this.id = id;
 }
 public double getBalance() {
    return balance;
 }
 public void setBalance(double balance) {
    this.balance = balance;
 }
 public void displayAll(){ 
    System.out.println( " Your ID : "+id);
    System.out.println( " Your Balance : "+balance);
    System.out.println( " Your annualInterestRate : "+InterestRate);
 }
 /**
 * @param args
 */
public static void main(String[] args) {
    Account A1=new Account(73, 4500000, 4.50);
    A1.setBalance(570000);
    A1.setId(74); 
    A1.deposit(45500);
   System.out.println(" Withraw amuount: "+ A1.withdraw(9000));

    A1.displayAll();
 }
}
