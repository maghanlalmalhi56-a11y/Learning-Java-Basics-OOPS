package a1;

public class PositiveAndNegativeSum {
    public static void main(String[] args) {
        System.out.println("k");
    }
}
