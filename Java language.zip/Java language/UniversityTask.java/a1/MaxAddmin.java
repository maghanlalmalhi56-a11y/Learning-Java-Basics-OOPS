package a1;

import java.util.Scanner;

public class MaxAddmin {
    public static void main(String[] args) {
        Scanner input=new Scanner ( System.in); 
    System.out.print( " Enter the size of arrays :");
       int size =input.nextInt(); 
    int[] num =new int[size]; 
     for( int i=0; i<num.length; i++){ 
        System.out.print( " Enter the element of arrays"+ ( 1+i)+" : ");
        num[i]=input.nextInt(); 
         

     }
     int postivesum = 0 ; 
        int negativesum=0;
        System.out.println( " Positive number : ");
        for( int i=0; i<num.length; i++){ 
        if( num[i]>0){ 
            System.out.println(num[i]+ " ");
            postivesum+=num[i];
        }
        }
         System.out.println( " Negative number : ");
        for( int i=0; i<num.length; i++){ 
        if( num[i]<0){ 
            System.out.println(num[i]+ " ");
            negativesum+=num[i];
        }
        }
        
    }

}                                                                 
                                                             
