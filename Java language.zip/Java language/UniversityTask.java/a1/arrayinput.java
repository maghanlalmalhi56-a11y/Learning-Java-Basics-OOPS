package a1;

public class arrayinput {

}
