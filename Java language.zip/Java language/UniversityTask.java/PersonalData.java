public class PersonalData {
    public static void main(String[] args) {
         System.out.println( "Welcome to Java world !");
         String name=" Maghan lal Malhi";
         String Fathername=" Bhugro mal ";
         String dept=" Computer science "; 
         int Age =20; 
         String nationality=" Pakistani ";
         String birthplace =" Umerkot"; 
        
         System.out.println( "Name: "+name );
         System.out.println("Father Name:"+Fathername);
         System.out.println("Department:"+dept);
         System.out.println("Age:"+Age);
         System.out.println("Nationality:"+nationality);
         
         System.out.println("birthplace:"+birthplace);
    }
}
