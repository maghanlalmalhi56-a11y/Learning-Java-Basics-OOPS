import java.util.Scanner;

public class ThreeDigitcheck {
    public static void main(String[] args) {
         Scanner input=new Scanner( System.in); 
         System.out.println( " Enter first number : ");
         int a=input.nextInt(); 
         System.out.println( " Enter Second number : ");
         int b=input.nextInt(); 
         System.out.println( " Enter Third number : ");
         int c=input.nextInt(); 
         if ( ( a+c>b)){ 
            System.out.println(" sum of first and last digit is greater than middle : " );
         }else if ( ( a+c<b)){ 
            System.out.println( "sum of first and last digit is less than middle :");
         }else{
             System.out.println( "sum of first and last digit is equal to  middle :");
         }
    }
}
