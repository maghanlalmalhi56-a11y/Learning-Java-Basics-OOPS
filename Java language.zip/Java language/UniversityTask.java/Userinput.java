import java.util.Scanner;
public class Userinput {
    public static void main(String[] args) {
        
    
    Scanner input= new Scanner(System . in);
System.out.print( "please enter your name :  ");
String name = input.next();
System.out.println(" Welcome to Mr "+name +" in our home  ");
System.out.print(" please enter first number : " );
int a =input.nextInt();
System.out.print(" Enter  second number : " );
int b= input.nextInt();
int sum = a+b;
System.out.println( " The sum of two integer is : "+ sum);








    }}