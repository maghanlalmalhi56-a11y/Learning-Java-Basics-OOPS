import java.util.Scanner;

public class LastDigitIfElse {
    public static void main(String[] args) {
         Scanner input = new Scanner(System.in);
         System.out.println( " Welcome to java world and code of last digit in English :\n ");
         System.out.print( " Enter four Digit : ");
         int num = input.nextInt(); 
         int LastDigit=num%10; 
         if ( LastDigit==0){ 
            System.out.println( " Zero");
          } else if (LastDigit==1){
                 System.out.println( " One");
        }else if (LastDigit==2){
             System.out.println( " Two");
        }else if (LastDigit==3){
            System.out.println("Three " );
        }else if (LastDigit==4){
            System.out.println( "Four");
        }else if (LastDigit==5){
            System.out.println( "Five ");
        }else if (LastDigit==6){
             System.out.println( "Six");
        }else if (LastDigit==7){ 
            System.out.println( "Seven ");
        }else if (LastDigit==8){
            System.out.println( " Eight ");
        }else if (LastDigit==9){
            System.out.println( " Nine ");
        }else { 
            System.out.println( " You enter invalid input ");
        }

                
            
         


    }
    
}
