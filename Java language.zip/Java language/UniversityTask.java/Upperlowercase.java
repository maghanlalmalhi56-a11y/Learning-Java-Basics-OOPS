import java.util.Scanner;

public class Upperlowercase {
    public static void main(String[] args) {
         Scanner input=new Scanner(System.in); 
         System.out.print( " Enter character :  ");
         char ch = input.next().charAt(0);
         int ascii=(int)ch;
         if( ascii>=65&&ascii<=90){ 
            System.out.println("IT is Uppercase   :"+ch);
         }else if ( ascii>=97&&ascii<=122){ 
            System.out.println( " IT is Lowercase : "+ch);
         }else if ( ascii>=48&&ascii<=57){
             System.out.println( "IT IS Digit :"+ch);
         }
         else { 
            System.out.println( " IT is special case :"+ch);
         }
    }
}
