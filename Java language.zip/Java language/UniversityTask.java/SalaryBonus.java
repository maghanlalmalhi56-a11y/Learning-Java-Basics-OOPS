import java.util.Scanner;

public class SalaryBonus {
    public static void main(String[] args) {
         Scanner input=new Scanner( System.in); 
         System.out.print( " Enter your year of service  : ");
         int year=input.nextInt();
         System.out.print( " Enter your salary : ");
         double salary=input.nextDouble();
         double bonus=0; 
         if( year>=10){ 
            bonus=salary*0.20;
         }else if ( year>=5){ 
            bonus=salary*0.10;
         }else { 
            bonus=0; 
         }
         System.out.println( " your bonus is : "+bonus);
         System.out.println(" Salary with the bonus : "+( salary+bonus));
    }
}
