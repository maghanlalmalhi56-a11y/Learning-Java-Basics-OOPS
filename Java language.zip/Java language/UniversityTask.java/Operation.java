import java.util.Scanner;
public class Operation {

    public static void main(String[] args) {
         Scanner input=new Scanner( System.in); 
         System.out.print( " Enter The First Number: ");
         double num1=input.nextDouble(); 
         System.out.print( " Enter The Second Number: ");
         double num2=input.nextDouble(); 
         System.out.print("Enter operation (+,*-,/):");
         char op  =input.next().charAt(0);
         if ( op=='+' ){
            System.out.println( " Addition of Two Numbers :"+(num1+num2));

         }else if (op=='-') {
            System.out.println("Subtraction of Two number :"+(num1-num2));
           
         } else if (op=='*'){
                System.out.println( " Multiplication of Two Number:"+(num1*num2));
            }else if (op=='/') {
                // if (num2!=0) {
                    
                // }
                 System.out.println("Division of Two number : "+(num1/num2));
            }else{
                System.out.println( " invalid input");
            }
    }
    
}


