import java.util.Scanner;

public class Triangle {
  public static void main(String[] args) {
     Scanner input=new Scanner(System.in); 
     System.out.print( " Enter the value of A: ");
     int a=input.nextInt(); 
     System.out.print( " Enter the value of B: ");
     int b=input.nextInt(); 
     System.out.print( " Enter the value of C: ");
     int c=input.nextInt(); 
     if( a+b+c==180){
        System.out.println( " Triangle is valid ");
     }else if ( a==90||b==90||c==90){
         System.out.println(" Right Angle Triangle  ");
     }else if ( a<90&&b<90&&c<90){
        System.out.println( "Acute Angle ");
     }else{
         System.out.println( " Obtuse Angle ");
     }
  }  
}
