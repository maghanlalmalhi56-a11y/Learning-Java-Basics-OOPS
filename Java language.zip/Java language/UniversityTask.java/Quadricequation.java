import java.util.Scanner;

public class Quadricequation {
    public static void main(String[] args) {
         Scanner input=new Scanner(System.in);
         System.out.print( "Enter the value of A : ");
         double a=input.nextDouble();
         System.out.print( "Enter the value of B: ");
         double b=input.nextDouble(); 
          System.out.print( "Enter the value of C: ");
         double c=input.nextDouble(); 
         double D=b*b-4*a*c;
         if( D>0){
            System.out.println( "Root is Real and Distinct ");
            
         }else if(D==0){
            System.out.println( " Root is Real and equal ");
         }else{
            System.out.println( " Root is imaginary ");
         }

    }
}
