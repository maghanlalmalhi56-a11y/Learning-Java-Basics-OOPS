import java.util.Scanner;

public class MethodsPassing {
    public static int []inputArr( int size){ 
        Scanner input=new Scanner( System.in); 
         int []arr=new int[size];
       
        for( int i=0; i<arr.length; i++){
        System.out.print( " Enter the Elements of Arrays  "+(1+i)+" : ");
        arr[i]=input.nextInt(); 
        }

        return arr;
    }
    public static int getSum( int []arr){ 
        int sum=0; 
         for( int i=0; i<arr.length;i++){ 
            sum+=arr[i];
         }
         return sum;
        
    }
    public static double average( int []arr){ 
        int average=0; 
        int sum=getSum(arr);
        
        return average=sum/arr.length; 
    }
    public static void main(String[] args) {
          Scanner input=new Scanner( System.in); 
          System.out.print( " Enter the size of arrays :");
          int size=input.nextInt(); 
          int []arr=inputArr(size);
          int sum=getSum(arr);
          double av =average(arr);
          System.out.println( " The Sum of arrays is : "+sum);
          System.out.println( " The Average of arrays is : "+av);
    }
}
