import java.util.Scanner;

public class ArrayTest {

public static void main(String[] args) {
//      System.out.println( " Welcome TO Array Class\n ");
//    int [] num = inputArr();
//    positiveNegativeSum(num); 

// }
//  public static int[] inputArr( ){ 
//     Scanner input=new Scanner( System.in);
//     System.out.print( " Enter the size of Array : ");
//       int size=input.nextInt();
//    int [] num=new int[size]; 
//    for( int i=0; i<size; i++){ 
//     System.out.print(" Enter the element of arrays "+ ( 1+i)+ " : ");
//     num[i]=input.nextInt(); 


     
   

/* 
Scanner input=new Scanner( System.in );
System.out.print( " Enter the size of array :");
int size=input.nextInt(); 
int num[] = new int[size];


for( int i=0; i<size ; i++){ 
 System.out.print( " Enter the element of arrays  "+ (1+i)+" : ");
 num[i]=input.nextInt();
}
*/
// for ( int a: num) {
//   System.out.print( a );
//   System.out.print(" ");
// }

// System.out.print(" The minimium arrays is : " );
//    min(num);
//   }
//  static void min ( int arr[]){ 
// int min = arr[0];
// for( int i=0; i<min; i++){ 
//   if (min>arr[i]) {
//      min=arr[i];
//   }
//   System.out.println( min);
// }

// int sum =0;
// int [][]num = { { 2,3,4 }, { 45, 67, 78}};
//  for( int i=0; i<num.length; i++){ 
// for ( int j=0; j<num[i].length; j++){
//     System.out.print( num[i][j]+ " ");
// } 
//    System.out.println(  " ");
//  }
// int sum[]=Sum(num);
// System.out.println( " The sum is "+ sum );

// System.out.print( get());

// }
//    public static int Sum(int[][] x ){ 
//     int sum=0; 
//     int [][]num =new int[ 2][3];
//  for( int i=0; i<num.length; i++){ 
// for ( int j=0; j<num[i].length; j++){
// sum=sum+num[i][j];
// } 
   
//  }
//  return sum; 
// inputArr(); 
// int[]num; 
// printArr(num);
// int []num = { 2, 4, 5 ,6};
// printArr(num);

// printArr(null);
 
// }
//   public static void printArr( int [ ]arr){ 

// for(int i=0; i<arr.length; i++){ 
//   System.out.print( arr[i]+" ");
 
// }
//   }
//   public static int[] inputArr( ){
//     Scanner input=new Scanner( System.in);
//     System.out.print( " Enter the size of Array : ");
//       int size=input.nextInt(); 
//       int [ ] num=new int[size]; 
//       for( int i=0; i<size; i++){
//         System.out.print( " Enter the value of arrays element  "+(1+i)+":");
//         num[i]=input.nextInt(); 
//       }
//     return num; 
//   }

// int sum =0;
// int [][]num = { { 2,3,4 }, { 45, 67, 78}};
//  for( int i=0; i<num.length; i++){ 
// for ( int j=0; j<num[i].length; j++){
//     // System.out.print( num[i][j]+ " ");
//       // System.out.print(  " ");
//    System.out.println(num[i][j]+num[i][j]);
// } 
 
//  }

//  int x=Sum();
//  System.out.println( x);
// }
// public static int Sum( ){ 
//   int num1[]= { 3,4,6,7};
//   int num2[]= { 2,4,6,6};
//   int sum=0; 
// for( int i=0;i<num1.length; i++){
  
//   sum+=num1[i]+num2[i] ;                              
// }

//   return sum; 





        Scanner input=new Scanner ( System.in); 
    System.out.print( " Enter the size of arrays :");
       int size =input.nextInt(); 
    int[] num =new int[size]; 
     for( int i=0; i<num.length; i++){ 
        System.out.print( " Enter the element of arrays"+ ( 1+i)+" : ");
        num[i]=input.nextInt(); 
         

     }
     int postivesum = 0 ; 
        int negativesum=0;
        System.out.println( " Positive number : ");
        for( int i=0; i<num.length; i++){ 
        if( num[i]>0){ 
            System.out.println(num[i]+ " ");
            postivesum+=num[i];
        }
        }
         System.out.println( " Negative number : ");
        for( int i=0; i<num.length; i++){ 
        if( num[i]<0){ 
            System.out.println(num[i]+ " ");
            negativesum+=num[i];
        }
        }
         System.out.println( " Zero number : ");
        for( int i=0; i<num.length; i++){ 
        if( num[i]==0){ 
            System.out.println(num[i]+ " ");
            
        }
        }
        System.out.println( " The positive sum : "+postivesum);
        System.out.println( " The negative sum : "+negativesum);
    }

}              





class Test1 {
    public static void main(String[] args) {

        int[] A = {25, 14, 12, 74, 58, 74, 98, 84, 15, 24};
        int[] B = {87, 11, 10, 81, 67, 94, 74, 82, 15, 87};

        double[] C = new double[A.length];

        for (int i = 0; i < A.length; i++) {

            int max, min;

            if (A[i] >= B[i]) {
                max = A[i];
                min = B[i];
            } else {
                max = B[i];
                min = A[i];
            }

            C[i] = max + (min / 100.0); // 👉 main logic
        }

        for (int i = 0; i < A.length; i++) {
            System.out.println(A[i] + " " + B[i] + " " + C[i]);
        }
    }
}