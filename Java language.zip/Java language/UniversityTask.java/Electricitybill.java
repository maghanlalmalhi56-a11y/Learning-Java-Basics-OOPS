import java.util.Scanner;

public class Electricitybill {
    public static void main(String[] args) {
         Scanner input=new Scanner( System.in);
         System.out.print( " Please enter consumed unit: ");
         int unit=input.nextInt(); 
         double bill =0; 
         if( unit<100){
            bill=unit*5;
         }else if ( unit<=300){
            bill=unit*7;
         }else{ 
            bill =unit*10;
         }
         System.out.println( " Total units .Rs = "+bill);
    }
}
