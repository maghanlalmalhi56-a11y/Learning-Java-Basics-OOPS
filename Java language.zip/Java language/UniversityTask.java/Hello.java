public class Hello {
    public static void main(String[] args) {
         System.out.println( " Hello World !\n");
         System.out.println( " Welcome to JAVA World");
         
    }
}
