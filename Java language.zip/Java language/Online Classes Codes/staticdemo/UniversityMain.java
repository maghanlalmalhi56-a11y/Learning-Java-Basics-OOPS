/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package staticdemo;

/**
 *
 * @author HAROON TRADERS
 */
public class UniversityMain {
    public static void main(String[] args) {
        
         //University duet = new University(101, "DUET", "General Uni", "Karachi");
         University duet = new University();
         duet.setUniID(101);
         duet.setName("DUET");
         duet.setLocation("Karachi");
         duet.setType("Engineering");
         University ned = new University(2, "NED", "Engineering Uni", "Karachi");
         University jsmu = new University(3, "JSMU", "Medical", "Karachi");
         ned.setChancellor("Syed Qaim Ali Shah");
         duet.setChancellor("Murtaza Wahab");
         jsmu.setChancellor("Governor is Chancellor");
         duet.display();
         ned.display();
         jsmu.display();
   
    }
    
}
