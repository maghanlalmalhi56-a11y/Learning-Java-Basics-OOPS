/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package staticdemo;

/**
 *
 * @author HAROON TRADERS
 */
public class StudentMain {
    static {
        System.out.println("I am static block calling");
    }

    public static void main(String[] args) {
        System.out.println("I am Main Method calling....");
        // System.out.println("Student Count: "+Student.totalNumberOfStudent());
        OuterClass.InnerClass inn = new OuterClass.InnerClass();
        System.out.println(inn.b);

    }
}
