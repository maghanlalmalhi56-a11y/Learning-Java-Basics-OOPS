/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package staticdemo;

/**
 *
 * @author HAROON TRADERS
 */
public class OuterClass {
    int a = 5;
    
    public static class InnerClass{
        int b = 20;
    }
}
