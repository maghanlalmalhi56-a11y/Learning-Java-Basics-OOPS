/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package staticdemo;

/**
 *
 * @author HAROON TRADERS
 */
public class Student {
    int id;
    String name;
    static int countStudent = 0;
    static String vc = "Ali";

    public Student(int id, String name) {
        this.id = id;
        this.name = name;
        countStudent++;

    }

    public void display() {

        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
    }

    public static int totalNumberOfStudent() {

        return countStudent;
    }

}
