/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package staticdemo;

/**
 *
 * @author HAROON TRADERS
 */
public class University {
    private int uniID;
    private String name;
    private String type;
    private String location;
    private static String chancellor = "Syed Murad Ali Shah";

    public University() {
        this.location = null;
        this.name = null;
        this.type = null;
        this.uniID = 0;
    }
    
    public University(int uniID, String name, String type, String location) {
        
        this.uniID = uniID;
        this.name = name;
        this.type = type;
        this.location = location;
    }

    public void setUniID(int uniID) {
        
        if(uniID>100){
            System.out.println("You are NOT allowed to register");
            return;
        }
        this.uniID = uniID;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setChancellor(String chancellor) {
        this.chancellor = chancellor;
    }

    
    public int getUniID() {
        return uniID;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public String getLocation() {
        return location;
    }

    public String getChancellor() {
        return chancellor;
    }
    
    
    public void display(){
    
        System.out.println("***************** "+name+"***************** ");
        System.out.println("University ID:  "+this.getUniID());
        System.out.println("Chancellor of University: "+chancellor);
        System.out.println("Type of University: "+type);
        System.out.println("Location of University: "+location);
    }
}
