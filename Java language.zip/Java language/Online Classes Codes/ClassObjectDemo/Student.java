/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClassObjectDemo;

/**
 *
 * @author HAROON TRADERS
 */
public class Student {
    // 1. fields
    // 2. Methods
    int rollNo;
    String name;
    String dpt;
    int fees;
    
    public void initializeStudent(int rN, String sName, String sDpt, int f){
        rollNo = rN;
        name = sName;
        dpt = sDpt;
        fees = f + 5000;
        display();
    }
    public void display(){
    
        System.out.println("Roll No:    "+rollNo);
        System.out.println("Name:   "+name);
        System.out.println("Department: "+dpt);
        System.out.println("Student Fees: "+fees);
    }
}
