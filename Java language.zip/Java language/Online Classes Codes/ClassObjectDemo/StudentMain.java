/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClassObjectDemo;

/**
 *
 * @author HAROON TRADERS
 */
public class StudentMain {
    public static void main(String[] args) {
//        Student aijaz = new Student();
//        
//        Student aqsa = new Student();
//        aijaz.initializeStudent(15, "Muhammad Aijaz","Computer Science",10000);
//        System.out.println("*********1st Student***********");
//       
//        aijaz.display();
//        
//        aqsa.initializeStudent(20, "Aqsa Ahmed","Computer Science",20000);
//        System.out.println("*********2nd Student***********");
//        aqsa.display();
        
        System.out.println("Annoymous Object");
        new Student().initializeStudent(100, "Annoymous Student", "BS VR", 10000000);
        
        
        
    }
}
