/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arrays;

/**
 *
 * @author HAROON TRADERS
 */
public class Jani {
    public Jani(String st) {
        this("one","two");
        System.out.println("One Parameter:   "+st);
    }
    public Jani() {
        this("one");
        System.out.println("I am default");
    }
   
    public Jani(String st, String st2) {
        
        System.out.println("One Paremeter:   "+st);
        System.out.println("Two Parameter:   "+st2);
    }
    
}
