/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author HAROON TRADERS
 */
public class TwoDArrayMain {
    
    public static void main(String[] args) {
        
        
        TwoDArrayOperation obj = new TwoDArrayOperation();
//        int myArr[][] = twoD.inputArray();
//        
//        twoD.displayArray(myArr);
//        double avg = twoD.avgOfmyArr(myArr);
//        System.out.println("Average of myArr is:    "+avg);
        System.out.println(obj.add(20,5,10,35));
        
        
        
//        twoD.oneArg(2);
//        twoD.oneArg(2,3);
//        twoD.oneArg(2,3,4,5);
//        twoD.oneArg(2,3,4,45,5,6,6,67,7);
//        twoD.twoArg(2,3);
//        twoD.threeArg(2,3,4);
//        twoD.fiveArg(2,3,4,5,6);
        
    }
            
}
