


import java.util.Scanner;

public class ArrayMain {
    public static void main(String[] args) {
        
       ArrayTests at = new ArrayTests();
       Scanner sc = new Scanner(System.in);
       int[] arr = at.inputArray();
       at.printArr(at.inputArray());
       int l = at.printLargest(arr);
       System.out.println("\nLarges element in the array is: "+l);
       
       System.out.print("Enter any key to search");
       int search = sc.nextInt();
       System.out.println("item found: "+at.searchElement(arr,search));
      
          // Jani jani = new Jani();
                  
                  

     }
}
