/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */



import java.util.Scanner;


public class TwoDArrayOperation {
    public void displayArray(int arr[][]){
        for(int xAr[]:arr){
            for(int x:xAr){
                System.out.print(x +" ");
            }
            System.out.println("");
            
        }
    }
    
    public double avgOfmyArr(int arr[][]){
        double avg;
        int sum = 0;
        int n = 0;
        for(int xAr[]:arr){
            for(int x:xAr){
                
                sum = sum + x; 
                n++;
            }
           
            
        }
        System.out.println("Sum of Array is:    "+sum);
        System.out.println("No. of Elements in array is:    "+n);
        avg = (double)sum / n; //type cast
        
        return avg;
    }
    
    public int[][] inputArray(){
        Scanner sc = new Scanner(System.in);
        int myArr[][] = new int[2][3];
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print("Enter value at:"+i+" row:"+j+" coloumn");
                myArr[i][j] = sc.nextInt();
            }
        }
        return myArr;
    }
    
    
    public int add(int c, int... sum){
        int sumOfAll = 0;
        for (int x:sum) {
            sumOfAll += x;
        }
        return sumOfAll;
    }
    public void oneArg(int... one){
        System.out.println("");
        System.out.println(one.length+" argument method");
        for (int i:one) {
            System.out.print(i+" ");
        }
    }
    
}