/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 *

/**
 *
 * @author HAROON TRADERS
 */
public class ArrayTests {
    
    public void printArr(int ar[]){
        for(int x:ar){
            System.out.print(x+" ");
        }
    }
    
    public int printLargest(int ar[]){
        
        int largest = ar[0];
        for (int i = 0; i < ar.length; i++) {
            if(largest <= ar[i]){
                largest = ar[i];
            }
        }
        return largest;
    }
    
    public int[] inputArray(){
    
        int arr2[] = {10,200,30,40,50,60,70,80};
        return arr2;
    }
    
    public boolean searchElement(int arr[],int key){
    
        for (int i = 0; i < arr.length; i++) {
            if(key == arr[i]){
                return true;
            }
        }
        return false;
    }
}
