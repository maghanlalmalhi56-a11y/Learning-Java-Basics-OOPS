/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package constructor;

/**
 *
 * @author HAROON TRADERS
 */
public class Teacher {
    int tID;
    String name;
    String dpt;
//    
//    Teacher() {
//        this(2);
//        System.out.println("I am default");
//        
//    }
//
//    Teacher(int tID){
//        this(1,"hello");
//        System.out.println("I am one parameterized");
//    }
//    Teacher(int id, String name){
//        
//        System.out.println("I am two parameterized");
//    }
    Teacher(int tID, String name, String dpt) {
        System.out.println("I am three parameterized");
        this.tID = tID;
        this.name = name;
        this.dpt = dpt;
    }
    Teacher(Teacher t1){
        this.tID = t1.tID;
        this.name = t1.name;
        this.dpt = t1.dpt;
    
    }
    
    public void show(){
    
        System.out.println("ID: "+tID);
        System.out.println("Name: "+name);
        System.out.println("Department: "+dpt);
    }

    // constructor chaining
    
}
