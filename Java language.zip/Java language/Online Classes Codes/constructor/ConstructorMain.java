/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package constructor;

/**
 *
 * @author HAROON TRADERS
 */
public class ConstructorMain {
    public static void main(String[] args) {
        Student st1 = new Student();
        st1.show();
        Student st2 = new Student(5);
        st2.show();
        Student st4 = new Student(5,"Ali");
        st4.show();
        Student st3 = new Student(5,"Ali","Computer Sceince",20000);
        st3.show();
    }
}
