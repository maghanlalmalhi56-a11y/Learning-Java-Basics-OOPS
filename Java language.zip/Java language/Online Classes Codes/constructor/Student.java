/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package constructor;
public class Student {
    
    int sID;
    String sName;
    String sDpt;
    int dues;
    
    Student(){
        sID = 0;
        sName = null;
        sDpt = null;
        dues  = 0;
        System.out.println("I am default Constructor");
    }
    
    Student(int... id){
        System.out.println("I am one parameterized Constructor");
        sID = id[0];
    }
    Student(int id, String name){
    
        System.out.println("I am two parameterized Constructor");
        sID = id;
        sName = name;
    }

    public Student(int sID, String sName, String sDpt, int dues) {
        this.sID = sID;
        this.sName = sName;
        this.sDpt = sDpt;
        this.dues = dues;
    }
    
    public void show(){
    
        System.out.println("Student ID: "+sID);
        System.out.println("Student Name: "+sName);
        System.out.println("Student Department: "+sDpt);
        System.out.println("Student Remaining Dues: "+dues);
    }
}
