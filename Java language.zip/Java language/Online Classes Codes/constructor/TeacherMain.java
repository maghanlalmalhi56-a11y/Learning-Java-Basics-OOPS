/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package constructor;

/**
 *
 * @author HAROON TRADERS
 */
public class TeacherMain {
    public static void main(String[] args) {
        Teacher t1 = new Teacher(1,"Muhammad Saleem","CS");
        Teacher t2 = new Teacher(t1);
        t2.show();
    }
}
