/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package encapsulation;

/**
 *
 * @author HAROON TRADERS
 */
public class DUET {
    private String vc;
    private String registrar;
    private int noOfEmployees;

    public DUET(String vc, String registrar, int noOfEmployees) {
        this.vc = vc;
        this.registrar = registrar;
        this.noOfEmployees = noOfEmployees;
    }
    
    // Read only methods
    public String getVC(){
        return vc;
    }
    public String getRegistrar(){
        return registrar;
    }
    public int getNoOfEmployees(){
        return noOfEmployees;
    }
    // write only methods

    public void setVc(String vc) {
        this.vc = vc;
    }
    public void setNoOfEmployees(int noOfEmployees) {
        this.noOfEmployees = noOfEmployees;
    }

    public void setRegistrar(String registrar) {
        this.registrar = registrar;
    }
    
    
    public void display(){
    
        System.out.println("DUET VC:    "+vc);
        System.out.println("DUET Registrar:    "+registrar);
        System.out.println("DUET No of Employees:    "+noOfEmployees);
    }
}
