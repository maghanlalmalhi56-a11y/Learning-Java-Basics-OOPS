/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package encapsulation;

/**
 *
 * @author HAROON TRADERS
 */
public class DUETMain {
    public static void main(String[] args) {
        DUET duet = new DUET("Dr. Samreen", "Dr. Syed Asif Shah", 1600);
        DUET duet2 = new DUET("Dr. Samreen", "Dr. Syed Asif Shah", 1600);
        duet.display();
        
        
        duet.setVc("Dr. Fazullah Abbasi");
        duet.setRegistrar("Mr. Farshad");
        duet.setNoOfEmployees(2000);
        duet.display();
                
    }
}
