public class StaticDemo {

    int a;  // IT throw compiler error becauses it is nonstatic variable 
  public static int cubic(int x){ 
    return x*x*x; 
  }
  public static void greet(){ 
    System.out.println( " Welcome TO java World !");     }
    public static void main(String[] args) {
       StaticDemo.greet();   // Don't need to create a object if you use static keyword with methods or variables 
    
     int result= cubic(5); 
     System.out.println( " The cubic calculation with the static method is : "+result);
    //  System.out.println( a);  // Error because of nonstatic variable 

     

    }

}
