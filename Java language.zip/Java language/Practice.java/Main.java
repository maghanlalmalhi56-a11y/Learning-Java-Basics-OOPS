
    
 
//  class Student {  
//     int id;  
//     String name;  
//     String Tname; 
//     static String University=" Apna college";
//     Student( int id , String name , String Tname ){ 
//         this.name=name; 
//         this.id=id; 
//         this.Tname=Tname; 
//     }
    
    
//     public void displayInformation() {  
//         System.out.println("Student ID: " + id);  
//         System.out.println("Student Name: " + name);
//          System.out.println("Teacher Name: " + Tname);  
//         System.out.println("University Name:"+University);
//     }  
    
// }  
// public class Main {  
    
//     public static void main(String[] args) {  
//         // Creating objects of Student class with constructor  
//         Student student1 = new Student(2, "Maghan lal ", " Sir Saleem ");
//         Student student2 = new Student(45, "Anil Kumar ", " Sir Saleem  ");  
//         // Displaying information of the objects  
//         student1.displayInformation();  
//         student2.displayInformation();  
    
//     }  
// }  

