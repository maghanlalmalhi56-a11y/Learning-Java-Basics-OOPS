public class DemoThis {
    String name,course; 
    int id; 
    float fees; 
    DemoThis(int id , String name, String course  ){ 
    this.course=course; 
    this.id=id; 
    this.name=name; 

    }
      DemoThis(int id , String name, String course, float fees  ){
          
           this.fees=fees; 
    
        this(id, name, course); // Direct reuse by this keyword and no ambiguity between two constructor overloading
        // this.fees=fees; 
    }

    // public void display(){ 
    //     System.out.printf( " Name : "+name+" "+"ID :" +id + " "+" Course : "+course+ " "+ " Fees: "+fees);
    // }
     public void display(){ 
        System.out.printf(name+" " +id + " "+course+ " "+ +fees);
    }
      public static void main(String[] args) {
         DemoThis t1= new DemoThis(73, "Maghan lal ", " java Programming ");
         DemoThis t2= new DemoThis(73, "Maghan lal ", " java Programming ", 25000);
         t1.display();
         t2.display();

        }
}
