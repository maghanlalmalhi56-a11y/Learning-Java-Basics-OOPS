public class AccessModifiers {
    private int x=9; 
    private int d=7;
 /* 
    private AccessModifiers(){
    private message(){ 
        System.out.println( " Welcome to java world ");
    }
        
}
    */
}
 class D {
  public static void main(String[] args) {
    //  AccessModifiers a1=new AccessModifiers(); 
    //  a1.message(); // it throws error is due to private access modifiers which means in the same class you used or outside class it throws error 
  }
    
}