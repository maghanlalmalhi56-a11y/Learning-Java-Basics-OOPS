import java.util.Scanner;

 class Temperatureconversion {
    public static void main(String[] args) {
         Scanner input = new Scanner(System .in);
         System.out.print( " Enter value in fehrenhit  : ");
         double tempF=input.nextDouble();
         double celsuis=(tempF-32)*5/9;
         System.out.println( "The temperature in celsuis : "+celsuis+"C");
    }
    
}
