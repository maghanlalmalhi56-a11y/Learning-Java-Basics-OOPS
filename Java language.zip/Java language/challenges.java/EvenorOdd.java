import java.util.Scanner;

public class EvenorOdd {
   public static void main(String[] args) {
     Scanner input=new Scanner(System.in);
     System.out.print( " Enter a number charater : ");
            int num=input.nextInt(); 
            if(num%2==0&&num>0){ 
                 System.out.println(" You entered a Positive Even number :"+num);
            }else if (num%2==0&&num<0) { 
                    System.out.println( " You entered a Negative Even number ");            
            }else if (num%1==0&&num>0) { 
                System.out.println( " You entered a Positive Odd number : "+num);

            }else if (num%1==0&&num<0){ 
                System.out.println( " You entered a Negative Odd number ");
            
            } 

   } 
}
