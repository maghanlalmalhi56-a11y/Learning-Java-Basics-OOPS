// import java.util.Scanner;
// // for two digit reversing the position of two number 
// public class ReversetheDigit {
//     public static void main(String[] args) {
//          Scanner input=new Scanner (System.in); 
//          System.out.print( " Enter two digit number : ");
//          int num=input.nextInt(); 
//          int reverse=(num%10)*10+(num/10);
//          System.out.println(" THE reverse number is : "+reverse);
//     }
// }

 // Method N0=2 for the 'N' number is given find the reverse of the digit 

import java.util.Scanner;
// for two digit reversing the position of two number 


 class ReversetheDigit {
    public static void main(String[] args) {
         Scanner input=new Scanner (System.in); 
         System.out.print( " Enter the Numbers   : ");
         int num=input.nextInt(); 
       int reverse=reverse(num);
         System.out.println(" THE reverse number is : "+reverse);
          
    }        
    public static int  reverse ( int num){ 
        int newnum=0; 
        while ( num>0) {
            int digit=num%10; 
             
            newnum=newnum*10+digit; 
            num/=10;
        }
    
        return newnum; 
    }
}