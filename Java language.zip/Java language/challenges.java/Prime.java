import java.util.Scanner;

class Prime {
    public static void main(String[] args) {
        System.out.println( " Welcome to java world "); 
        Scanner input=new Scanner ( System.in ); 
        System.out.print( " Enter a positive number : ");
        int num=input.nextInt();
       boolean isprime =isprime(num);
       if( isprime){
        System.out.println( "Your number is prime ");
       }else { 
        System.out.println( " Your number is not prime ");
       }
        
    }
    public static boolean isprime( int num ){ 
        int i=2; 
        while ( i<num ) {
             
        if (num%i==0) {
             return false; 
    
        }
       i++; 
        
        }
         return true; 
    }
}
