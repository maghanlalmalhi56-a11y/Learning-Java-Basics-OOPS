import java.util.Scanner;

public class Perimeter {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println(" Welcome to calculator of perimeter of rectangle : ");
        System.out.println( " Enter the value perimeter in centimer meter ");

        System.out.print(" Enter the value of A:");
        int A = input.nextInt();
        System.out.print(" Enter the value of B:");
        int B = input.nextInt();

        System.out.print(" Enter the value of C:");
        int C = input.nextInt();

        System.out.print(" Enter the value of D:");
        int D = input.nextInt();
        int rectanglePerimeter = A + B + C + D;

        System.out.println(" The perimeter of Rectangle : " + rectanglePerimeter);
    }
}
