import java.util.Scanner;

public class Areaoftriangle {
    public static void main(String[] args) {
         Scanner input= new Scanner (System . in); 
         System.out.println( " Welcome to calculator of triangle ");

         System.out.print( "Please Enter the value of Base of Triangle : ");
         double base = input.nextDouble(); 
         System.out.print( " Now Enter the value of Height : ");
         double height =input.nextDouble(); 
         double AreaOfTriangle = (height*base)*1/2;


         System.out.println( " The Area of the Triangle : "+ AreaOfTriangle);
    }
}
