import java.util.Scanner;

public class GradeMarks {
    public static void main(String[] args) {
        Scanner input=new Scanner (System .in);
        System.out.println( " Welcome to grading marks system \n\n");
        System.out.print( " please Enter your marks : ");
         int marks=input.nextInt();
         if ( marks>90){ 
              System.out.println( " you got A grade ");
         }else if ( marks >80 ){ 
            System.out.println( " You got B grade ");
         }else if (marks > 60 ){ 
            System.out.println( " you got C grade ");
         }else if (marks > 40){ 
            System.out.println( " you got D grade ");
         }else {
            System.out.println( " you entered invalid input");
         }

    }
}
