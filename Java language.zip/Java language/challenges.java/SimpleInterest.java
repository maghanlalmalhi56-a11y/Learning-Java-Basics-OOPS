import java.util.Scanner;

public class SimpleInterest {
 public static void main(String[] args) {
     Scanner input=new Scanner(System.in );
     System.out.print( " Enter the value of time in second : ");
     float time =input.nextFloat(); 
     System.out.print( " Enter the value of Rate of interest : ");
     float Rate = input.nextFloat() ;
     System.out.print(" Enter the value of principle amount in Rupees  : ");
     int principle=input.nextInt();

     float SimpleInterest=(principle*Rate*time)/100;


     System.out.println( " The Simple Interest :  "+SimpleInterest);
 }
    
}
