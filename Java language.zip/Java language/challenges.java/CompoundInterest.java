import java.util.Scanner;

public class CompoundInterest {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println(" Welcome to compound Interest calculator \n\n");
        System.out.print(" Enter the value of principle of compound interest in terms Rs : ");
        int principle = input.nextInt();
        System.out.print(" Enter the value of time of compound interest in term of years : ");
        float year = input.nextFloat();
        System.out.print(" Enter the value of Rate of compound interest : ");
        float rate = input.nextFloat();
        double compoundInterest = principle *Math.pow ((1 + rate / 100) , year);
        
        System.out.println( " The value of compound interest is : "+compoundInterest);
    }

}
