import java.util.Scanner;

class LCM {
    public static void main(String[] args) {
              System.out.println( " Welcome to Least Common Calculator (LCM) \n");
        Scanner input = new Scanner( System. in);
        System.out.print( " Enter First positive Number : ");
        int num1 = input.nextInt();
     System.out.print( " Enter  Second Number : ");
       int num2=input.nextInt();
       int lcm=LCM(num1, num2);
       System.out.println( " The LCM : "+lcm);
       
    }
    public static int LCM(int num1, int num2 ){ 
      int i=1; 
     
      while (true) {                    // (i<=num2);
        int factor=i*num1;
      if (factor%num2==0) {
          
        return factor;
      }
      i++;
       }
                                                //  return 0;  // unreachable condition
    }
}
