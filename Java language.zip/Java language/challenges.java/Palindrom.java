import java.util.Scanner;

class Palindrom {
    public static void main(String[] args) {
          Scanner input=new Scanner (System.in); 
          System.out.println( " Welcome to palindrome number checker ");
         System.out.print( " Enter First number : ");
         int num=input.nextInt(); 
         boolean ispalindrom=ispalindrom(num); 
       if ( ispalindrom ) {
        System.out.println( " Your number is palindrom ");
    
       }else { 
        System.out.println( " Your number is not palindrome ");
       }
    }
    public static boolean ispalindrom( int num ){ 
        int reverse = reverse( num);
        return num==reverse;
    }
     public static int  reverse ( int num){ 
        int newnum=0; 
        while ( num>0) {
            int digit=num%10; 
             
            newnum=newnum*10+digit; 
            num/=10;
        }
    
        return newnum; 
}
}
