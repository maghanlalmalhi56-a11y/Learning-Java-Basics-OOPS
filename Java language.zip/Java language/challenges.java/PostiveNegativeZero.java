import java.util.Scanner;

public class PostiveNegativeZero {
    public static void main(String[] args) {
         Scanner input=new Scanner (System .in); 
        System.out.print( " Please Enter a number : "); 
        int num=input.nextInt(); 
        if( num==0){ 
            System.out.println( " You entered Zero number :"+num);
        }else if (num>0){ 
            System.out.println( " you entered Positive number : "+num);
        }else if ( num<0){
               System.out.println( "  You entered Negative number :"+num);
        }else{ 
            System.out.println( " you entered invalid input ");
        }
            
        
}
}