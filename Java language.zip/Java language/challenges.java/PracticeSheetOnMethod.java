import java.util.Scanner;

public class PracticeSheetOnMethod {
    public static void main(String[] args) {
         System.out.println( " Welcome to Multiplication Table \n ");
          System.out.println( "#********** Multiplication Table **********#" );
        //  Scanner input=new Scanner( System.in);
        //  System.out.print( " Enter number : ");
        //  int num=input.nextInt(); 
        //  num=Table(num); 
        
        // Table(3);     // Direct method
    }
    public static int Table( int num){ 
       
         for( int i=1; i<=10;i++){ 
            
          System.out.println( num+" X "+i+" = "+(i*num)); 
         }
     return 0; 
    }
         
    
}
