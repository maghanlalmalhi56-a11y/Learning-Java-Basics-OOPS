// import java.util.Scanner;

//  class MultiplicationTable {
//     public static void main(String[] args) {           //  Method No=01
//     Scanner input = new Scanner( System.in); 
//     System.out.print( " Enter a postive Integer : ");
//     int num = input.nextInt(); 
//      System.out.println( "******** The Multiplication Tabale of :" +num+ "********");
//     for ( int i = 1 ; i<=10 ; i++){     
//       int table = (i*num );
      
//       System.out.println( num+"x"+i+"="+table);
//     } 
//     }
// }


// Method No=02 

import java.util.Scanner;

 class MultiplicationTable {
    public static void main(String[] args) {          
    Scanner input = new Scanner( System.in); 
    System.out.print( " Enter a postive Integer : ");
    int num = input.nextInt(); 
     System.out.println( "******** The Multiplication Tabale of " +"********");
      printMultiplicationTable(num);
    }
    public static void printMultiplicationTable ( int num ){ 
     
     int i=1; 
     while ( i<=10) {
       int table = (i*num );
      
      System.out.println( num+"x"+i+"="+table);
      i++;
     }
    
    }
}
