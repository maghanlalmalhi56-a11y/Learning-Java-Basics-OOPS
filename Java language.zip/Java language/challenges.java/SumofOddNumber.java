
 
import java.util.Scanner;
class SumofOddNumber {
    public static void main(String[] args) {
         Scanner input=new Scanner( System.in); 
         System.out.println(" *****Welcome to java world*****\n ");
         System.out.print( "Enter a Positive integer : ");
         int num=input.nextInt(); 
         int sum=OddSum(num);
         System.out.println( "OddSum till "+num+"  is: "+ sum);
    }
    public static int OddSum( int num ){ 
int sum=0;
    int i=1;
     while ( i<=num) {
        sum=sum+i; 
        i+=2; 
        
     }
     return sum; 
    }
}