
// Method No=1


import java.util.Scanner;

 class Factorial {          
    public static void main(String[] args) {
        System.out.println( " Welcome to Factorial calculation \n");
        Scanner input = new Scanner( System. in);
        System.out.print( " Enter a positive Number : ");
        int num = input.nextInt();
      long fact=Factorial(num); 
       System.out.println( " The Factorial of "+num+"!="+fact);
    }
    public static long Factorial( int num ){ 
          long fact=1;
        int i=1; 
        while ( i<=num) {
          fact*=i;
          i++; 

        }
        return fact; 
    }
}


// Method No=2; 
// import java.util.Scanner;

//  class Factorial {
//     public static void main(String[] args) {
//         System.out.println( " Welcome to Factorial calculation \n");
//         Scanner input = new Scanner( System. in);
//         System.out.print( " Enter a positive Number : ");
//         int num = input.nextInt();
//         long fact=1;

//        for( int i=1;i<=num;i++){
//         fact*=i; 
//        }
//         System.out.println( " The Factorial of "+num+"!="+fact);
//     }
// }