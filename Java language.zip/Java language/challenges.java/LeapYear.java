import java.util.Scanner;

public class LeapYear {
    public static void main(String[] args) {
         Scanner input= new Scanner(System .in ); 
         System.out.println( " Welcome to Leapyear finding program \n");
         System.out.print( " Enter The value of year  : ");
         int year = input.nextInt(); 
         if ( year%400==0||(year%4==0 &&  year%100!=0)){ 
            System.out.println( " Your year is leap year ");
         }else System.out.println("Your year is not leap year " );
         
            
         
    }
}
