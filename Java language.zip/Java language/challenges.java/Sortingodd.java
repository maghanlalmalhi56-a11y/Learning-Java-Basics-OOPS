public class Sortingodd {
    public static void main(String[] args) {
    
         System.out.println( );
    }
}
