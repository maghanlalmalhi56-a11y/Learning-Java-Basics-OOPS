// Method No=01
// import java.util.Scanner;

//  class GCD {
//     public static void main(String[] args) {
//          Scanner input= new Scanner( System.in); 
//          System.out.print( " Enter first number : ");
//          int num1= input.nextInt(); 
//           System.out.print( " Enter Second number : ");
//           int num2 = input .nextInt(); 
//           while ( num1!=num2) {
//             if ( num1>num2){
//                 num1 = num1-num2; 
                
//             }else { 
//                 num2=num2-num1; 
//             }
//             System.out.println( " The GCD : "+num1);
//           }
//             }
// }



// Method No=02

 import java.util.Scanner;

class LCM {
    public static void main(String[] args) {
              System.out.println( " Welcome to Greatest common Division (GCD) \n");
        Scanner input = new Scanner( System.in);
        System.out.print( " Enter First positive Number : ");
        int num1 = input.nextInt();
     System.out.print( " Enter  Second  Number : ");
       int num2=input.nextInt();
       int GCD=GCD(num1, num2);
       System.out.println( " The GCD : "+GCD);
       
    }
    public static int GCD(int first, int second ){ 
      int gcd=1; 
      int i=2; 
      int Least=least(gcd, i);
      return gcd;
    }
    public static int least(int num1,int num2){
        if ( num1>num2){
            return num1; 
        }else{
            return num2; 
        }
         return least; 
    }
}