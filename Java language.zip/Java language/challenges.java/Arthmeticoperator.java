import java.util.Scanner;

public class Arthmeticoperator {
    public static void main(String[] args) {
        Scanner input= new Scanner(System.in); 
        //   System.out.print( " Enter the value of the of First number : ");
        //  int a=input.nextInt();
        //  System.out.print( " Enter the value of Second number : ");
        //  int b= input .nextInt(); 
       
        // int sum =a+b; 
        // System.out.println( "a+b:"+sum);
        // int difference= a-b; 
        // System.out.println("a-b:"+difference);
        // int product=a*b; 
        // System.out.println( "a*b:"+product);
        // double ratio= a/b; 
        // System.out.println( " a/b:"+ratio);
        // double mod = a%b;
        // System.out.println("a%b : "+mod);


         System.out.print( " Enter the value of the of First number : ");
         int a=input.nextInt();
         System.out.print( " Enter the value of Second number : ");
         float b= input .nextFloat(); 
         float product = a*b; 
         System.out.println( "a*b: "+product);
    }
    
}
