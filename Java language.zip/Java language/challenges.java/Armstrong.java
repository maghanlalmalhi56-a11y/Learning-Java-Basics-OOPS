import java.util.Scanner;

class Armstrong {
    public static void main(String[] args) {
          Scanner input=new Scanner (System.in); 
         System.out.print( " Enter First number : ");
         int num=input.nextInt(); 
         System.out.println( "Here is the number is Armstrong number checker  ");
         boolean isArmstrong=isArmstrong(num ); 
         if (isArmstrong) {
            System.out.println( " THe number is Armstrong ");
         }else { 
            System.out.println( " Number is not Armstrong ");
         }
    }
    public static boolean isArmstrong( int num ){ 
        int noOFDigit=noOfDgit(num); 
        int numCopy=num;
        int finalNumber=0; 
        while ( num>0) {
            int lastdigit = num%10; 
               num/=10; 
               finalNumber=+pow(lastdigit, noOFDigit); 
        
        }
         return finalNumber==numCopy; 
    }
    public static int pow ( int num1 ,int num2){ 
        int result=1;
        int i = 0; 
        while ( i<num1) {
            result*=num1; 
            i++; 
        }
        return result;  
    }
    public static int noOfDgit( int num ){
        int digit=0; 
        while( num>0){ 
            digit++; 
            num/=10; 
        }
         return digit; 
    }
}
