

// write a code to swap to numbers 
 // Method 1 = ( Addition and substractiom method )

import java.util.Scanner;

public class Swapping {
    public static void main(String[] args) {
    //   int a = 3 ; 
    //    int  b= 4; 
    //    System.out.println( " Before swapping a : "+a );
    //    System.out.println( " Before swapping b : "+b );
    //    a=a+b; 
    //    b= a-b;
    //     a = a-b; 
    //     System.out.println("AFTER Swapping a : "+a );  
    //     System.out.println("AFTER Swapping b : "+b);  


// Method 2 = ( Multiplication and division method )
   Scanner input  = new Scanner(System.in);
         System.out.print( " please enter First number A  : ");
        int a = input.nextInt();  
        System.out.print( " Please enter Second number B: ");
     int b= input.nextInt(); 
       System.out.println( " Before Swapping A : "+a);
       System.out.println( " Before Swapping B : "+b);
       a=a*b;
        b= a/b; 
        a= a/b; 
        System.out.println( " After Swapping A : "+a);
        System.out.println( " After Swapping B : "+b);

    } 
}
