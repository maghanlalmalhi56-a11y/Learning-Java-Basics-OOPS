import java .util.Scanner;
public class RaceMain{ 
     public static void main ( String []args ){ 
           System.out.print( "Enter time taken by A : ");
           Scanner input = new Scanner ( System .in ); 
           int timeA = input.nextInt();
            System.out.print( " Enter time taken by B : ");
            int timeB =input.nextInt(); 
            double pi = 3.14; 
            int diameterA = 15; 
            int diameterB= 20; 
            double speedA = (( 2*pi* diameterA/2))/timeA;
            double speedB = (( 2*pi* diameterA/2))/timeB;

               if ( speedA > speedB){ 
                    System.out.println( " Anil kumar running faster than kanwar ");
               }else { 
                    System.out.println( " Kanwar ram is faster than anil kumar ");
               }


     }
     
}