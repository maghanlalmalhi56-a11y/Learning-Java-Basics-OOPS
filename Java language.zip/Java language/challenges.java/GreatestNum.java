import java.util.Scanner;

public class GreatestNum {
    public static void main(String[] args) {
         Scanner input=new Scanner ( System.in); 
         System.out.print( "Welcome to predictor of largest number \n\n ");

         System.out.print( " Enter First number : ");
         int num1 = input.nextInt(); 
           System.out.print( " Enter Second number : ");
            int num2 = input.nextInt();
             System.out.print( " Enter Third number : "); 
              int num3 = input.nextInt();
              if( num1>=num2&&num3<=num1){
                System.out.println( " First number is Greatest number : "+num1);
              }else if (num1<=num2&&num3<=num2) {
                System.out.println( " Second number is Greatest number : "+num2);
                
              }else if (num1<=num2&&num3>=num2){
                System.out.println( "Third number is Greatest number :"+num3);
              }
         
    }
    
}
