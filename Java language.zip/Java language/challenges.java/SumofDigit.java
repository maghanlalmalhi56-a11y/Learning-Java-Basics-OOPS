// Method No=1
// import java.util.Scanner;

// public class SumofDigit {
//     public static void main(String[] args) {
//            System.out.println( " Welcome to Factorial calculation \n");
//         Scanner input = new Scanner( System. in);
//         System.out.print( " Enter Three positive Number : ");
//         int num = input.nextInt();
//         int Sum =(num/100)+((num%100)/10)+(num%10);
//         System.out.println( " The compute sum of integer number  :"+Sum);
//     }
// }


// Method No=2 

import java.util.Scanner;

 class SumofDigit {
    public static void main(String[] args) {
           System.out.println( " Welcome to Factorial calculation \n");
        Scanner input = new Scanner( System. in);
        System.out.print( " Enter N positive Number : ");
        int num = input.nextInt();
        int sum=SumofDigit(num);
        System.out.println( " The sum of compute digit : "+sum);
    }
    public static int SumofDigit( int num ){ 
        int sum=0;
        while ( num>0){
            sum+=(num%10);    // sum=sum+(num%10);
            num/=10;      // num = num/10;
        } 
         return sum; 
    }
}
