import java.util.Scanner;

public class Salarybonus {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print(" Enter your salary : ");
        double salary = input.nextDouble();
        System.out.print(" Enter your attendence : ");
        int atten = input.nextInt();
        if (atten > 90) {
            salary = salary * 2;
            // System.out.println(" Your salary after Bonus :" + salary);
        }
        else if (atten > 70) {
            salary = salary + (salary/2);
            
        }
        
        System.out.println("Salary afterbonus is:"+ salary);

    }
}
