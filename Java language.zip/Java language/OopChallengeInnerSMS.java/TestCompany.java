 class Birthday {
    String month;
    int day, year; 
            
    Birthday(int day, String month, int year){
        this.day=day; 
        this.month=month; 
        this.year=year; 

    }
      public String toString() {
        return day + "-" + month + "-" + year;
    }

}
class PersonWithDetail {

    private String name; 
    private Birthday dob;
    private Address adr;
    
   public PersonWithDetail(String name, Birthday dob , Address a){
        this.adr=a; 
        this.name=name; 
        this.dob=dob; 
    }
  public void display() {
        System.out.println("Name: " + name + "\nDOB: " + dob + "\nAddress: " + adr);
}
}
class Address{
int zipCode;
String city ,province, country;
Address(int zipCode, String city , String province, String country){
    this.zipCode=zipCode; 
    this.city=city; 
    this.country=country; 
    this.province=province; 

}
public String toString() {
        return city + ", " + province + " (" + zipCode + "), " + country;
}
}        
public class TestCompany {  
public static void main(String [] args){          
Birthday b1 = new Birthday(2, " Feb",2002);  

Address ad1 = new Address(7900, "jacobabad","Sindh","Pakistan");


PersonWithDetail   p1 = new PersonWithDetail("Saleem",b1,ad1);  
System.out.println("\n******* Person-Details *******\n");
p1.display();
System.out.println("\n******* Birth-day *******\n");
System.out.println(b1);
System.out.println("\n******* Address *******\n");
System.out.println(ad1);

}
}