 class Message {
    protected String text; 
    
    public String toString( ){ 
        return text; 
    }
    public void setText(String text){ 
        this.text=text; 
    }
}
class SMS extends Message{
    String recipientContactNo; 
    SMS( String n , String text){ 
        this.recipientContactNo = n; 
        this.text=text; 
        System.out.println( );
    }

     public String toString( ){ 
        return  "To: " + recipientContactNo + " | Msg: " + text; 
    }
}

class Email extends Message { 
    private String reciever , sender, subject; 
    Email ( String sender , String reciever, String subject , String text){ 
        this.reciever=reciever; 
        this.sender=sender; 
        this.subject=subject; 
        this.text=text;
    }
     public String toString( ){ 
        return  "From : " + sender + " | Subject : " + subject + " Body : "+ text; 

    }
    public static String encode(String msg) {
    char[] chars = msg.toCharArray();
    for (int i = 0; i < chars.length; i++) {
        if (Character.isLetter(chars[i])) {
            if (chars[i] == 'z') chars[i] = 'a';
            else if (chars[i] == 'Z') chars[i] = 'A';
            else chars[i]++;
        }
    }
    return new String(chars);
}
}

 class MessageMain {
public static void main(String[] args) {
     Message myMessage= new Message(); 
    System.out.println(" ******* Message *******");
     myMessage.setText( " \"Hey! Mr.Maghan lal how are you? \n");
     System.out.println(" Basic Message : "+myMessage);
    

     System.out.println("******* Email *******");
     Email myEmail=new Email("maghan@mail.com", "saleem@mail.com", "Lab Task", "I have finished the code!" );
    System.out.println( " My Email: " + myEmail);
     
       String secret = Email.encode("Java"); 
       
        System.out.println("Encoded 'Java': " + secret);
         
         System.out.println("******* SMS *******\n");
        SMS mySms = new SMS("0300-1234567", "Call you later."); 
        System.out.println("SMS: " + mySms);
}
    
}