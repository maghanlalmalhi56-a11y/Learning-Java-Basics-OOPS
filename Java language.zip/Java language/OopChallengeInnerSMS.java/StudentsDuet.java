public class StudentsDuet {
    int id; 
    String name ;
   static String collage= " SPSC" ; 
    static void change(){ 
    collage=" Kianant ";

}
 StudentsDuet(  String name , int id){ 
  this.id= id; 
  this.name=name;
  
 }
public  void display(){
    System.out.println( id + " " + name +  " "+ collage);
}
public static void main(String[] args) {
    StudentsDuet.change();
    StudentsDuet st1=new StudentsDuet(" Maghan lal ", 73);
    StudentsDuet st2=new StudentsDuet(" Tanveer  ", 76);
    
   st1.display();
   st2.display();

}
}

