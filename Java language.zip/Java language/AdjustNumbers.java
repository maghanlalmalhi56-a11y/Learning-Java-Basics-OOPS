import java.util.Scanner;

public class AdjustNumbers {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number a: ");
        double a = sc.nextDouble();

        System.out.print("Enter number b: ");
        double b = sc.nextDouble();

        if (a > b) {
            a = a + (a * 0.10);   // increase a by 10%
            b = b - (b * 0.10);   // decrease b by 10%
        } else {
            a = a - (a * 0.05);   // decrease a by 5%
            b = b + (b * 0.05);   // increase b by 5%
        }

        System.out.println("Final value of a = " + a);
        System.out.println("Final value of b = " + b);
    }
}
    
