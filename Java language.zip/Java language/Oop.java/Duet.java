 class Duet {
private String vc; 
private String rsgtr; 
private int salary; 
Duet(String vc, String rsgtr, int salary){ 
    this.rsgtr=rsgtr; 
    this.vc=vc; 
    this.salary=salary; 
}
public void display(){ 
     System.out.println( " VC Name : "+ vc);
     System.out.println( " Registarar Name : "+ rsgtr);
     System.out.println( " Salary : "+ salary);
}
 public void setVc( String n){ 
    this.vc=n;
 }
  public void setRgstr( String n){ 
    this.rsgtr=n;
 }
 public String getvc( ){ 
    return vc; 
 }
 public String getRgstr( ){ 
    return rsgtr; 
 }
  }

