class MyEmployee {
   private  int id; 
   private String name; 
   public void setName( String n){ 
    this.name =n; 
   }
   public String getName( ){
    return name;  
   }
    public int getId( ){
        return id; 
    }
    public void setId( int i ){
        this.id=i; 
    } 
    public static void main(String[] args) {
       MyEmployee Emp1=new MyEmployee(); 
      Emp1.setId(73);
      Emp1.setName(" Maghan lal ");
      System.out.println(Emp1.getId());
      System.out.println(Emp1.getName());
    }
}
