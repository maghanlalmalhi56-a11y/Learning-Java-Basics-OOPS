// public class Main {
//      public static void main(String[] args) {
//         Employee emp1=new Employee(73, 455000, "Computer Science ", " Mukesh kumar "); 
//         emp1.display();
//      }
// }
