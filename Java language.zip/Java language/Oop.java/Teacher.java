public class Teacher {
    int tID;
    String name;
    String dpt; 
    Teacher(int tID, String name, String dpt) {
        System.out.println("I am three parameterized");
        this.tID = tID;
        this.name = name;
        this.dpt = dpt;
    }
    Teacher(Teacher t1){
        this.tID = t1.tID;
        this.name = t1.name;
        this.dpt = t1.dpt;
    
    }
    
    public void show(){
    
        System.out.println("ID: "+tID);
        System.out.println("Name: "+name);
        System.out.println("Department: "+dpt);
    }
   public static void main(String[] args) {
    Teacher t1=new Teacher(73 , " Maghan lal ", " Computer science");
    t1.show();
   }
}
