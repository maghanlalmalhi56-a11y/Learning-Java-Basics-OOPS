 class Pen {
    
        
    
    String colour; 
    String type; 
    public void write(){ 
        System.out.println(" Writing something ");
    }
    public void printColour(){ 
        System.out.println(this.colour);
    }
   public void printType(){ 
    System.out.println( this.type);
   }
 }
 class Student{
  int id; 
  String name; 
  Student( int id, String name ){ 
    this.id=id; 
    this.name=name; 
  }
  public void display(){ 
    System.out.println(id+ " "+name);
    
}
}

public class Oop{
public static void main(String[] args) {
    Pen pen1= new Pen(); 
    Pen pen2= new Pen(); 
    pen1.colour= " Red"; 
    pen1.type= " Gel"; 
    pen1.write();
    pen1.printColour();
    pen1.printType();
    pen2.colour=" Blue"; 
    pen2.type=" Ballpoint"; 
    pen2.printType();
    pen2.printColour();
    Student Maghan= new Student(73, "Maghan lal Malhi ");
    Maghan.display();

   
    
}
}


