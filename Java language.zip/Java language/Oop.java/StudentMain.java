public class StudentMain {
    int id; 
    String name; 
    StudentMain(int i, String n){ 
 id=i; 
 name=n; 
     
    } 
    void display(){ 
        System.out.println( id  +" : " + name);
    }
    public static void main(String[] args) {
        StudentMain s1= new StudentMain( 73, " Maghan lal ");
        StudentMain s2= new StudentMain( 65, " Aneel kumar ");
        s1.display();
        s2.display();
    }
}
