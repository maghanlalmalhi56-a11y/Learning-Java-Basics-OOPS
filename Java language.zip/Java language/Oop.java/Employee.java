//   class Employee {
//     int id; 
//     String name; 
//     int  salary; 
//     public void printdetails( ){
//         System.out.println( "My Name is "+name);
//          System.out.println( " My ID is "+id);
//     }
//     public int getSalary(){
//         return salary;  
//     }
//     public static void main(String[] args) {
//         System.out.println( " welcome to Employee class\n ");
//         Employee emp1=new Employee();
//         Employee emp2=new Employee(); 
//         Employee emp3=new Employee(); 
//         emp1.id=12; 
//         emp1.name=" Sam";
//         emp1.salary=12000; 
//         emp1.printdetails();
//         int salary=emp1.getSalary(); 
//         System.out.println( salary);
//     }
    
// }



// class Employee {
//     String name;
//     int yearOfJoining;
//     int salary;
//     String address;

//     Employee(String name, int yearOfJoining, int salary, String address) {
//         this.name = name;
//         this.yearOfJoining = yearOfJoining;
//         this.salary = salary;
//         this.address = address;
//     }

//     void display() {
//         System.out.printf("%-10s %-15d %-10d %-20s\n", name, yearOfJoining, salary, address);
//     }
// }

// public class Main {
//     public static void main(String[] args) {
//         Employee e1 = new Employee("Robert", 1994, 20000, "64C- WallsStreat");
//         Employee e2 = new Employee("Sam", 2000, 15000, "68D- WallsStreat");
//         Employee e3 = new Employee("John", 1999, 18000, "26B- WallsStreat");

//         System.out.println("Name       Year of joining   Salary     Address");
//         e1.display();
//         e2.display();
//         e3.display();
//     }
// }

public class Employee {

     String name; 
     int id; 
     double salary; 
     String dep; 
     Employee( int id,  double salary , String dep , String name ){
        this.name=name; 
        this.dep=dep;
        this.id=id;
        this.salary=salary;  

     }
     void display( ){ 
        System.out.println( " Employee Name : "+name+ " and "+" ID: " +id+ " "+" Salary is :"+salary+" "+" Department :"+dep);
     }
    
}
