import java.util.Scanner;

public class Puppy {
    //   public Puppy( String name){ 
    //      System.out.println( " Passed Name : "+ name);
    // }
     public static void main(String[] args) {
         System.out.println( " Welcome to Dog classes \n ");
        //  Puppy mypuppy=new Puppy(" Mukesh kumar "); 


    // There are Three Ways  intialize the Objects 
     // 1. By Constructor 
     // 2. By Method 
     // 3. By Reference 

     


    }
}


