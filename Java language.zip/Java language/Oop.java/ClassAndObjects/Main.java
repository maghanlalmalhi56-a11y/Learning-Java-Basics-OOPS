package ClassAndObjects;

    class Student {  
    int id;  
    String name;  
    String Tname; 
    Student( int id , String name , String Tname){ 
        this.name=name; 
        this.id=id; 
        this.Tname=Tname; 
    }
    
    
    public void displayInformation() {  
        System.out.println("Student ID: " + id);  
        System.out.println("Student Name: " + name);
         System.out.println("Teacher Name: " + name);  
    }  
}  
public class Main {  
    
    public static void main(String[] args) {  
        // Creating objects of Student class with constructor  
        Student student1 = new Student(2, "Maghan lal ", " Sir Saleem ");
        Student student2 = new Student(2, "Jane Smith", " Maghan lal Malhi ");  
        // Displaying information of the objects  
        student1.displayInformation();  
        student2.displayInformation();  
    }  
}  

