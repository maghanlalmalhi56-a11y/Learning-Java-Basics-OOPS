public class Driver {
     static int minAgeOfDriving=18;
    String name; 
    String dateOfLicences; 
    int age;

    public boolean IsAllowedToDrive(){
        return this.age>=minAgeOfDriving;
    }
    public static void main(String[] args) {
    //  Car myCar=new Car();
    //  myCar.addFuel(6);
    //  myCar.Drive();
    
    //  System.out.println(myCar.getCurrentFuelLevel());

    Car swift=new Car(" Red");
    swift.addFuel(6);
    swift.start().Drive();
    System.out.println(swift.colour);
//    Driver MyDriver=new Driver(); 
//    MyDriver.dateOfLicences="1/2024/july"; 
//    System.out.println(minAgeOfDriving);

       
    }
     
    
}
