public class Car {
    int noOfWheels; 
    float currentLevelOfFuelInLitre; 
    float addFuel; 
    int noOfSeats; 
    String colour; 
    float maxSpeed; 
    Car(String colour){// constructor 
        noOfSeats=4;
        this.colour=colour;
        maxSpeed=130;
        currentLevelOfFuelInLitre=2;
        noOfSeats=5;
    }
    public Car start(){
        if (currentLevelOfFuelInLitre==0) {
            System.out.println(" Car is out off fuel ");
           
        }else if (currentLevelOfFuelInLitre<=5) { 
        System.out.println( " Car is reversed mode, please refuel as soon as possible ");
         currentLevelOfFuelInLitre--;
        }else{
        System.out.println( " Car is Started ...........bruhhh!");
        currentLevelOfFuelInLitre--; 
        
        }
        return this; 
    }
    public void Drive( ){ 
       
        System.out.println( " Car is Driving");
        currentLevelOfFuelInLitre--; 
        
    }
    public void addFuel( float currentLevelOfFuelInLitre){ 
        this.currentLevelOfFuelInLitre+=currentLevelOfFuelInLitre;
    }
    public float getCurrentFuelLevel( ){ 
        return currentLevelOfFuelInLitre; 
    }
}
