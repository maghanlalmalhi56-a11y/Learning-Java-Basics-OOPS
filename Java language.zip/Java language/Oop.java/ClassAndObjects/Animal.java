package ClassAndObjects;

public class Animal {
    public void eat(){ 
        System.out.println( " Eating ");
    }
}
class Dog extends Animal{ 
    public void bark(){ 
        System.out.println(" Barking ");
    }
}
    
class Babydog extends Dog{ 
 public void weep(){ 
    System.out.println( " Weeping ");
 }
 public static void main(String[] args) {
    Babydog b1=new Babydog(); 
    b1.bark();
    b1.weep();
    b1.eat();
 }
}