 class Encapsulation {
    /**
     * @param args
     */
    public static void main(String[] args) {
      Duet d1=new Duet(" Dr Maghan lal ", " Dr Samreen " ,560000);
    //   d1.setRgstr(" Sidra Khan ");
    //   d1.setVc( " Mukesh kumar ");
     
       d1.display();
    //    System.out.println(d1.getvc());
    //    System.out.println(d1.getRgstr());
        }
}
