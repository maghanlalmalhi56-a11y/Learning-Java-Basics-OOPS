package com.inheritance;

public class Calculation {
    public static void main(String[] args) {
        System.out.println(" Hi");
    }
}
