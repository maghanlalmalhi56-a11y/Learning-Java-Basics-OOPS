import java.util.Scanner;

public class ForEachLoop {
    /**
     * @param args
     */
    public static void main(String[] args) {
         int []numb =  { 45, 57, 67 , 89 , 90 };
         for(int x:numb){ 
          System.out.println(x);
         }
        //  int[] arr = {10, 20, 30};

// for(int num : arr)
// {
//     System.out.println(num);
// }
         
    }
}
