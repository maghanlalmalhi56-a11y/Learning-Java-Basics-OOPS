public class VariableAgrument {
    public static void main(String[] args) {
         System.out.println( " Welcome to varags Method \n");
         System.out.println( " The sum of 3 and 5 : "+sum(3, 5));
         System.out.println( " The sum of 3 , 5 and 7 : "+sum(3, 5,6));
         System.out.println( " The sum of 3 ,  5 and 7 , 7  : "+sum(3, 5,7,7));
       
         
     }
    // static int sum( int a , int b){ 
        
    //  return (a+ b); 
    // }
    // static int sum ( int a, int b , int c){ 
    //     return a+b+c; 
    // }
    // static int sum ( int a ,int b , int c , int d){ 
    //     return  a+b+c+d; 
   
    

    // Using varags 
     static int sum(int ...arr){  // if we want something in our result so we have write a like this sum(int x , int ...arr)  and resul=x;
         int result=0;
         for( int element: arr){ 
            result+=element; 
         }
         return result; 
     }
     
 
     

}
