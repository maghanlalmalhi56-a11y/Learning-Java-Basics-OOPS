import java.util.Scanner;

public class TernaryOperator {
    public static void main(String[] args) {
        //  int Age =42;
        //  String Result= ( Age>=30)?"Pretty Old" : " TO YOung";
        
        //  System.out.println(Result);

        int time = 8; 
        String Result=( time>6)? " Good Morning .": " Good evening.";
        System.out.println(Result);
         
        Scanner input=new Scanner( System.in ); 
        System.out.print( " Please Enter a positive Integer : ");
        int num =input.nextInt();
            
        
    }
}
