public class Unaryoperator {
    public static void main(String[] args) {
        //  int x=5;
        //  x+=1; 
        //  System.out.println( x);
        //  x= x+1; 
        //   System.out.println( x);
        //  x=x++; 
        //  System.out.println( x);
        //  x=++x; 
        //  System.out.println( x);

        //  int y = 5;
        //   y=--y; 
        //   System.out.println( y);
        //   y=y--; 
        //   System.out.println( y );


        System.out.println( " Watching increment operator : ");
        int p=5;
         System.out.println( p++);
         System.out.println( p );
          System.out.println( ++p);
          System.out.println( p);

    }
    
}
