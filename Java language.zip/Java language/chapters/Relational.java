import java.util.Scanner;

public class Relational {
    public static void main(String[] args) {
         Scanner input= new Scanner (System .in); 
         System.out.println( " Welcome to java world ");
         System.out.print( " Enter your Age : ");
         int Age =input.nextInt(); 
         if ( Age >=18)
               System.out.println( " you are  elgible for a driving lincenese");
         else System.out.println( " you are not elgible for a driving lincenese ");
    } 

    
    
}
