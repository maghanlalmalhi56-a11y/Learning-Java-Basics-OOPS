import javax.management.monitor.StringMonitor;

public class Main {

  public static void main(String[] args) {
    MethodOverloading.Greeting();
    // System.out.println("Hello World");
    // System .out.println("My name is maghan lal malhi ");
    // System .out.println(" java is easy language ");
    // System .out.println(" Have a good day basit ali khan ");
    // Writing a simple number

    // System .out.println( 33);
    // System .out.println(4555);
    // System.out.println(46464);

    // using arthmetic operator such as( " + - * / ")
    // System.out.println(845+4564);
    // System.out.println(74*6);
    // System.out.println(874-34);
    // System.out.println(434/3);

    // variable in java ( string , int , boolean , float )
    // ( + ) symbol in java represent In Java For text (strings), it joins them
    // together (called concatenation).

    // string
    // String name1 = " Maghanlal malhi ";
    // String name2 = "Anil kumar ";
    // String name3 = " Kanwar Ram malhi ";
    // String name4= " Vijay kumar malhi ";
    // System.out.println("Hello"+ name1 );
    // System.out.println("Hello"+name2 );
    // System.out.println("Hello"+name3 );
    // System.out.println(name4 );
    // String name =" Maghan lal ";
    // String lastname="Malhi ";
    // String fullname= name+lastname;
    // System.out.println( fullname);
    // String name1 =" Maghan lal Malhi ";
    // String name2 = " Anil kumar Malhi ";
    // System.out.println(name1.length());
    // System.out.println(name2.length());

    // integers
    // int myNum1= 13;
    // int myNum2= 18;
    // int myNum3= 67;
    // int myNum4= 55;
    // int x=6;
    // int y=4;
    // System.out.println( "The sum is : "+x+y);
    // System.out.println( "The sum is : "+(x+y));
    // System.out.println(myNum1+19);
    // System.out.println(myNum2-2);
    // System.out.println(myNum3*3);
    // System.out.println(myNum4/2);

    // personal biodata

    // String name = " Maghan lal malhi";
    // String id = "25F-cs-073";
    // int age = 21;
    // char grade = 'A';
    // int fees = 74000;
    // System.out.println("Student name: " + name);
    // System.out.println("Student id: " + id);
    // System.out.println(" Student Age : " + age);
    // System.out.println(" Student Grade : " + grade);
    // System.out.println(" Student Fees :" + fees);

    // int x = 23, y = 34;
    // int sum = x+y;
    // System .out.println("the sum of two number:" sum);
    // int x=45, y= 34, z=32;
    // int sum =x+y+z;
    // System.out.println(sum );
    // int x , y;
    // x=y=20;
    // int sum = x+y;
    // System.out.println( " sum is : "+sum);

    // char
    // char ch1= 'a';
    // System.out.println(ch1);
    // char ch2='b';
    // System.out.println(ch2);

    // identifiers ( names )
    // String studentName = " Maghanlalmalhi";
    // int studentId = 73;
    // int studentFees = 5770;
    // int studentAge = 20;
    // char studentGrade

    // (Addition or concatention  )
    // // System.out.println("StudentName:"+studentName);
    // System.out.println("StudentId :"+studentId);
    // System.out.println("StudentFees :"+studentFees);
    // System.out.println("StudentAge :"+studentAge);
    // System.out.println("StudentGrade :"+studentGrade);
    // String firstName = " Maghan lal ";
    // String lastName = " Malhi";
    // System.out.println(firstName + " " + lastName);

    // int length = 34;
    // int width = 4;
    // int area = length * width;
    // System.out.println(area);

    // primitive data type
    // int myNum= 15;
    // char myLetter = 'D';
    // float num= 23.4f;
    // boolean myBool = true ;
    // System.out.println(myNum);
    // System.out.println(myLetter);
    // System.out.println(myBool);
    // System.out.println(num);

    // long myNum = 24342;
    // double myNum1= 343.3434;
    // char myVar1= 65;
    // char myVar2= 97;

    // System.out.println(myNum);
    // System.out.println(myNum1);
    // System.out.println(myVar1);
    // System.out.println(myVar2);

    // logical operator such as ( and , or logical not )
    // int x = 4 ;
    // int y= 3;
    // // System.out.println(x>y& x<y);
    // System.out.println(x>y||x<y);
    // System.out.println(!(x>y));
    // System.out.println(!(x<y));
    // System.out.println(4>3&3<4);
    // System.out.println(4<3&4>4);
    // System.out.println(3>4||4>3);
    // System.out.println(!(3>4));
    // int a= 34;
    // int b= 50;
    // System.out.println( 34>50&& 50>34);
    // System.out.println( 50>34|| 50<34);
    // System.out.println(! (50>34));

    // if -else condition
    // int age = 15;
    // if ( age >=20) {
    // System.out.println(" you are eligble for vote ");
    // }else {
    // System.out.println( " You are not eligble for the vote ");
    // }

    // swapping of two number without the third variable
    // int a= 4;
    // int b= 3;
    // System.out.println("Before Swapping a :"+a );
    // System.out.println("Before Swapping b :"+b);
    // a = a+b;
    // b=a-b;
    // a= a-b;
    // System.out.println(" After Swapping a : " +a );
    // System.out.println(" After Swapping b : " +b );

    // swapping of two number with involving third variable

    // int a= 4;
    // int b= 3;
    // int temp;
    // System.out.println("Before Swapping a :"+a );
    // System.out.println("Before Swapping b :"+b);
    // a=b;
    // b=a;
    // temp =a;

    // System.out.println("After swapping a :"+a );
    // System.out.println("After swapping b :"+b);

    // int a= 4;
    // int b= 3;
    // int

    // changing the two digit position means ( 87 =78)
    // int a=87;
    // a=(a%10)*10+(a/10);
    // System.out.println("inverse of two digit a: "+a);

    // int a=34;
    // a=(a%10)*10+(a/10);
    // System.out.println( "inverse of 34: " +a );

    // int a=123;
    // a=(( a%100)%10)*100+((a%100)/10)*10+(a/100);
    // System.out.println(a);

    // int num = 345;

    // int d1 = num % 10;
    // int d2 = (num / 10) % 10;
    // int d3 = num / 100;

    // int reversed = d1 * 100 + d2 * 10 + d3;

    // System.out.println(reversed);


    //  patterns 
    System.out.println( "* * * * * ");
    System.out.println( "* * * *  ");
    System.out.println( "* * *  ");
    System.out.println( "*  ");

    
  
  }
}