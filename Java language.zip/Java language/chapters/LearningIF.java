import java.util.Scanner;

public class LearningIF {
    public static void main(String[] args) {
         Scanner input=new Scanner( System.in);
        //  System.out.print( "Please Enter your Age : ");
        //  int age =input.nextInt();
        //  if(age>=18){
        //     System.out.println( "Your Eligible for Vote "+age);
        //  }



        // boolean isMale= true; 
        // String name = "Maghanlal"; 
        // if (isMale) {
        //     System.out.println( " MR "+name);

                // }  

            // boolean isSeniorCitizen =true; 
            // boolean isadult=false; 
            // if(isSeniorCitizen){ 
            //     System.out.println( "Hello senoir citizen ");
            // }else if(isadult){
            //     System.out.println(" hello adult" );
            // }else{
            //      System.out.println( " invalid input ");
            // }

       // Even and odd number code 


            // System.out.print( " Enter a number charater : ");
            // int num=input.nextInt(); 
            // if(num%2==0){ 
            //      System.out.println(" You entered a Even number :"+num);
            // }else if (num%1==0) { 
            //     System.out.println( " You entered a Odd number : "+num);

            // }else{ 
            //     System.out.println( " Invalid input");
            // }

            

            // upper-case and lower-case Method No=01

            // System.out.print( " Enter a single charater : ");
            // char ch= input.next().charAt(0);
            // if ( ch>='A'&&ch<='Z'){ 
            //     System.out.println( " You entered uppercase :"+ch );
            // }else if( ch>='a'&&ch<='z'){ 
            //     System.out.println( " You entered lowercase : "+ch);
            // }else { 
            //     System.out.println( "You entered special letter ");
            // }

            
          // Method No=02
           System.out.print( " Enter a single charater : ");
         char ch= input.next().charAt(0);
            if ( ch>=65&&ch<=97){ 
                System.out.println( " You entered uppercase :"+ch );
            }else if( ch>=97&&ch<=126){ 
                System.out.println( " You entered lowercase : "+ch);
            }else { 
                System.out.println( "You entered special letter ");
            }
      
    }
    
}
