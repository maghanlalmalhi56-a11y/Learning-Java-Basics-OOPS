public class escapesequence {
    public static void main(String[] args) {
         //System.out.println( " Maghan lal 'Malhi'");
        //  System.out.println(" Maghan lal \"Malhi\" ");
        //   System.out.print( " Maghan lal \n malhi ");
        // System.out.println( " South city \t in 'umerkot'");
        // System.out.println( " South city \\ in 'umerkot\\'");

        // System.out.println( " * \n * * \n * * *\n * * * * ");

        // System.out.println( " * * * * \n * * * \n * * \n * ");
        
        System.out.println();
      
    }
    
}
