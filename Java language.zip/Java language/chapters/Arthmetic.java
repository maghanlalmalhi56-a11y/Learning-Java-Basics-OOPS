import java.util.Scanner;

public class Arthmetic {
    public static void main(String[] args) {
        // Addition
        // System.out.print( " Enter First integers : ");
        Scanner input = new Scanner(System.in);
        // int num1= input.nextInt();
        // System.out.print( " Enter second number : ");
        // int num2=input.nextInt();
        // int sum = num1+num2;
        // System.out.println( " The Sum of two integers : "+sum );

        // multiplication
        // System.out.print(" Enter First integers : ");
        // int num1 = input.nextInt();
        // System.out.print(" Enter second number : ");
        // int num2 = input.nextInt();
        // int sum = num1 * num2;
        // System.out.println(" The product of two integers : " + sum);

        // Division 
        //   System.out.print(" Enter First integers : ");
        // double num1 = input.nextDouble();
        // System.out.print(" Enter second number : ");
        // double num2 = input.nextDouble();
        // double sum = num1 / num2;
        // System.out.println(" The product of two integers : " + sum);

         
        // Modulus operator 
         System.out.print(" Enter First integers : ");
        int num1 = input.nextInt();
        System.out.print(" Enter second number : ");
        int  num2 = input.nextInt();
        double sum = num1 % num2;
        System.out.println(" The modulus  of two integers : " + sum);

    }

}
