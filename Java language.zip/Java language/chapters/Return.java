
// import java.util.Scanner;

// public class Return {
//     public static void main(String[] args) {
//         greeting();
//         int First = readNumber(); 
//         int Second=readNumber();
//         System.out.println( "The of sum "+(First+Second));
//     }
//      public static int readNumber (){
//         Scanner input=new Scanner(System.in); 
//         System.out.print( " Please Enter Number : ");
//         int number=input.nextInt();
//         return number;
         
//      }
//     public static void greeting() {
//         System.out.println( " Welcome to java World \n");
        
//     }
// }



// import java.util.Scanner;

// public class Return {
//     public static void main(String[] args) {
//         greeting();
//         int rollNo=StudentData();
        
//         System.out.println(" your Roll Number is : "+rollNo);
//     }
//     public static void greeting() {
//       System.out.println( " Welcome to java World \n");
//       String name =" Maghan lal malhi " ;      
//     }
//     public static int StudentData(){
//      Scanner input = new Scanner(System .in ); 
//      System.out.print( " Enter the Roll number: ");
//      int rollNo=input.nextInt();
//      System.out.print( " Enter your name : ");
//      String name = input.next();  
   
//      return rollNo;
//     }
    

// }

 public class Return {
  public static void main(String[] args) {
    String name = " Keep"; 
    String reverse=" "; 
    for( int i=name.length()-1 ; i>=0; i++){
        reverse+=name.charAt(i);
    }
System.out.println( " Orginal String : "+ name);
System.out.println( " Reverse String : "+ reverse);
  }
}