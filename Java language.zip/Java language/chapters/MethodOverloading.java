public class MethodOverloading {
    public static void main(String[] args) {

         Greeting();
         System.out.println( " Hello Mr Maghan lal Nice to Meet you ");
         foo();
         foo(300);// Argument is actual = value
         foo(40, 50); 
    }  
    static void Greeting( ){ 
        System.out.println( " Welcome to in the Java World !\n");
    }
 // Methodoverloading 
  static void foo( ){ 
    System.out.println( " Good Morning bro! ");
  }
 static void foo( int a ){
     System.out.println( " Good morning "+ a+ " bro ! ");
 }
 static void foo( int a , int b ){ 
    System.out.println( " Good morning "+ a+ " bro ! "); 
     System.out.println( " Good morning "+ b+ " bro ! ");
 }
}
