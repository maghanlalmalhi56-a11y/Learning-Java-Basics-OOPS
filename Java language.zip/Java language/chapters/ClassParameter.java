public class ClassParameter {
    
   public static void main(String[] args) {
   
   // int sum = SumTwoNum(4 , 70); // in square brackets the terms 4 & 70  refer to Argument = value 
   // System.out.println( " The Sum of Two Number : "+sum);
   System.out.println( SumTwoNum(4, 70));
   System.out.println( SumTwoNum(5, 60));
   System.out.println( SumTwoNum(4, -4));



   }
    public static int SumTwoNum(int first, int second){  // in square brackets the terms first & second refer to parameter = name 
       System.out.println( " First number is recieved : "+first);
       System.out.println( " Second number is recieved : "+second);
        int sum = first + second; 
        System.out.print(" The Sum of Two number : ");
        return sum; 
    }
}




