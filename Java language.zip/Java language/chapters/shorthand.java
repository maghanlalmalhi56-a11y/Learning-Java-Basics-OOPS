import java.util.Scanner;

public class shorthand {

    public static void main(String[] args) {
     Scanner input = new Scanner(System.in );
     System.out.print(" Enter a integer :" );
     int a= 5; 
     int x1=input.nextInt(); 
    //    a=a+x1; 
      a+=x1;
      

      System.out.println(a);
      a-=3;
      System.out.println( a );
      a*=3;
      System.out.println( );
      a/=3;
      System.out.println( a);
      
    }
}
