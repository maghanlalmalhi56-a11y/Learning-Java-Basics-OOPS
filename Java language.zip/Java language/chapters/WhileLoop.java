import java.util.Scanner;

public class WhileLoop {
    public static void main(String[] args) {
        //  int num =1;  // intiallization 
        //  while (num<=10){   // condition 
        //     System.out.println( num);  // updated work 
        //     num+=1;  // num =num+1; 



        //    int num=500;  
        //  while (num>=200){   
        //     System.out.println(num);  
        //     num =num-1;
        //   }    
       
           

        int row =0; 
        while (row<5){
            System.out.print( "*");
            int i= 0; 
            while ( i<row){
                System.out.print( " *");
                i++;
            }
            row++;
            System.out.println( );
        }


    }
}
