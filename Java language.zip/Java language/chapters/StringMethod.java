public class StringMethod {
    public static void main(String[] args) {
         String name = "Maghan"; 
         System.out.println( name.toLowerCase());
         int value = name.length(); 
         System.out.println(  value );
         System.out.println(name.toUpperCase());
         String nontrimString = "        Harry      "; 
         System.out.println( nontrimString);
         System.out.println( nontrimString.trim());
         System.out.println( name.substring(3));
         System.out.println( name.substring(0));
         System.out.println( name.substring(1,4)); // end index is excluded

         System.out.println(name.startsWith("  harr"));
         System.out.println(name.charAt(0));
         System.out.println(name.charAt(1));

    }
}
