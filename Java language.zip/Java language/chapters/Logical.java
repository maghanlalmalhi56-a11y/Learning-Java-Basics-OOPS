import java.util.Scanner;

public class Logical {
    public static void main(String[] args) {
         System.out.println( "Welcome to Ticket Discount calculator \n");
         Scanner input= new Scanner ( System.in);
         System.out.print(" Please Enter your Age :" );
         int Age = input.nextInt(); 
        
         System.out.print( " Are you Female or MALe ?");
        
        boolean isFemale = input.nextBoolean(); 
         if ( Age<5){ 
            System.out.println( " You got 75% Discount ");
         }else if (isFemale){ 
            System.out.println( " you got 50% Discount ");

         }else if ( Age>60&& !isFemale){ 
            System.out.println( " you got 25% Discount ");
         }else { 
            System.out.println( " you entered invalid input ");
         }
    }
}
