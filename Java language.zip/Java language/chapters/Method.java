public class Method {
    public static void main(String[] args) {
         System.out.println( " Welcome to Method class \n");
         int a=7;
         int b=8; 
         int c; 
       //  Method obj=new Method();  // without using static we have to created a object of same class 
         // c=obj.logic(a, b); \
         c=logic(a, b);
         System.out.println( c);
           int a1=8;
         int b1=7; 
         int c1; 
         c1=logic(a1, b1); 
         System.out.println( c1);
    }  
   static int logic ( int x, int y ){   
    int z; 
     if (x>y) {
        z=x+y; 
     }else{
        z=(x+y)*5;
     }
    return z; 

   }
}
