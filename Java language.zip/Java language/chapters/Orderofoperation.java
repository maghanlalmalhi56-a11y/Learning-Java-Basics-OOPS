public class Orderofoperation {
    public static void main(String[] args) {
         System.out.println( 7+3*3);
         System.out.println( 8+8-2);
         System.out.println( 10/(3*3));
         System.out.println( 3*(45-4+4));
    }
}
