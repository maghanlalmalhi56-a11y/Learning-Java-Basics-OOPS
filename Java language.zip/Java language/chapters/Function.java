public class Function {
    public static void main(String[] args) {
         System.out.println( " In Method ");
         greetUser();
         System.out.println( " Code is completelly excuated ");
    }
    public static void greetUser(){ 
        System.out.println( " Welcome to java World ");


    }
}
