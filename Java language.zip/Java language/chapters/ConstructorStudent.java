public class ConstructorStudent {
    int id; 
    String name; 
    ConstructorStudent(int i, String n){ 
   id=i; 
   name=n; 
    }
     ConstructorStudent(){ // without parameterized constructor 
   id=77; 
   name=" Maghan lal "; 
    }
    ConstructorStudent(String name){  

   this.name=name; 
    }
    void display(){ 
        System.out.println( id+" : "+ name);
    }
    public static void main(String[] args) {
      ConstructorStudent St1=new ConstructorStudent(73, " Maghan lal ");
      ConstructorStudent St2=new ConstructorStudent(56, " Avinash kumar ");
      ConstructorStudent St3=new ConstructorStudent(45, " Sunder kumar ");
      ConstructorStudent St4=new ConstructorStudent();
      ConstructorStudent St5=new ConstructorStudent("Rano Mal");
      St1.display();
      St2.display();
      St3.display();
      St4.display();
      St5.display();
    }
}
