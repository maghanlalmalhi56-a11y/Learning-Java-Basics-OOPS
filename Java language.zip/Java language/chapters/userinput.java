import java.util.Scanner;

public class userinput {
    public static void main(String[] args) {
        //  Scanner input  = new Scanner(System.in);
        //  System.out.print( " please enter your name : ");
        //  String name = input.nextLine(); 
        //  System.out.println( " Hello "+ name);
        //  System.out.print(name +"Please enter your age : " );
        //  int age = input.nextInt(); 
        //  System.out.println(name+ " your age is : " +age);
        //  System.out.print(" please enter your height ");
        //  double height = input .nextdouble(); 
        //  System.out.println( name + " your height is : "+ height );
        //  System.out.print( " Enter your good habit : ");
        //  String habit=input.next() ;
        //  System.out.println( name+ "Your good habit is :  "+ habit);
        //  System.out.print(" Tell me about yourself : ");
        //  String personalQuestion= input.next() ; 
        //  System.out.println( name + " Your is personality is : "+ personalQuestion);
        //  System.out.println( " PLease enter your favourite subject : ");
        //  String subject=input.next(); 
        //  System.out.println( name + " Your favourite subject is : "+subject);



Scanner input= new Scanner(System . in);
System.out.print( "please enter your name :  ");
String name = input.next();
System.out.println(" Welcome to Mr "+name +" in our home  ");

// Addition two number by input 
// Scanner input = new Scanner(System .in);

// System.out.print(" please enter first number : " );
// int a =input.nextInt();
// System.out.print(" Enter  second number : " );
// int b= input.nextInt();
// int sum = a+b;
// System.out.println( " The sum of two integer is : "+ sum);










//  Scanner input = new Scanner (System.in); 
//  System.out.print(" Enter a positive integer : ");
//  int num= input.nextInt(); 
// System.out.println( " You entered a number is equal to: "+num);
 



    }
}
