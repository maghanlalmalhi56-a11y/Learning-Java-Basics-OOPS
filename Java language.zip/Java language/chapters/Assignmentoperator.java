public class Assignmentoperator {
    public static void main(String[] args) {
        int myint = 9;
        System.out.println(myint);
        int myfloat = myint;
        System.out.println(myfloat);

        // if we write a code to assign left side a number it gives error
        // 9 =myint;
    }

}
